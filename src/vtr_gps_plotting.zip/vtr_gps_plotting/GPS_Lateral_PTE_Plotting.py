import os
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
import vtr_regression_testing.path_comparison as vtr_path
import json
import itertools
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

def align_path(file_path1, file_path2, omit_start1=0, omit_end1=0, omit_start2=0, omit_end2=0):
    """
    Aligns the ECEF data from file_path1 to the frame of file_path2 using trimmed data.
    
    The function:
      1. Loads the ECEF data for each file using load_ecef_txt.
      2. Trims the data based on the provided omit_start and omit_end values.
      3. Extracts the first valid measurement (first row's 'ECEF-X', 'ECEF-Y', 'ECEF-Z')
         from each trimmed dataset.
      4. Computes the translation vector as:
             translation_vector = first_point_file2 - first_point_file1
      5. Applies this translation to all rows of the trimmed data from file_path1.
      6. Returns the translated (aligned) DataFrame.
    
    Parameters:
        file_path1 (str): The file path for the dataset to be shifted.
        file_path2 (str): The file path for the reference dataset.
        omit_start1 (int): Number of rows to omit from the beginning of file_path1.
        omit_end1 (int): Number of rows to omit from the end of file_path1.
        omit_start2 (int): Number of rows to omit from the beginning of file_path2.
        omit_end2 (int): Number of rows to omit from the end of file_path2.
    
    Returns:
        pd.DataFrame: A DataFrame with the aligned (trimmed and shifted) ECEF data from file_path1.
    """
    # Load data from both files.
    df1 = load_ecef_txt(file_path1)
    df2 = load_ecef_txt(file_path2)
    
    # Apply trimming to df1 if necessary.
    if len(df1) > (omit_start1 + omit_end1):
        df1 = df1.iloc[omit_start1: len(df1) - omit_end1].reset_index(drop=True)
    
    # Apply trimming to df2 if necessary.
    if len(df2) > (omit_start2 + omit_end2):
        df2 = df2.iloc[omit_start2: len(df2) - omit_end2].reset_index(drop=True)
    
    # Extract the first valid ECEF measurement from each trimmed dataset.
    ref1 = df1[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].iloc[0].to_numpy()
    ref2 = df2[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].iloc[0].to_numpy()
    
    # Compute the translation vector.
    translation_vector = ref2 - ref1
    print("Reference point from file 1 (trimmed):", ref1)
    print("Reference point from file 2 (trimmed):", ref2)
    print("Computed translation vector to align file 1 to file 2:", translation_vector)
    
    # Apply the translation vector to all rows in df1.
    df1_aligned = df1.copy()
    df1_aligned[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = df1_aligned[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] + translation_vector
    
    return df1_aligned

def load_ecef_txt(path):
    # Read the file, skipping the first 16 rows, and assign column names manually.
    df = pd.read_csv(path, sep='\s+', header=None, skiprows=16, names=['ID', 'ECEF-X', 'ECEF-Y', 'ECEF-Z'])
    df = df.dropna()
    df['ID'] = pd.to_numeric(df['ID'], errors='coerce')
    df = df.dropna(subset=['ID']).reset_index(drop=True)
    df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].astype(float)
    return df

def path_to_matrix(gps_data):
    points = []
    for idx in range(1, len(gps_data)):
        x0 = gps_data.iloc[idx - 1].to_numpy()
        x1 = gps_data.iloc[idx].to_numpy()
        l = np.linalg.norm(x1 - x0)
        if l < 1e-6:
            continue
        n = (x1 - x0) / l
        row = np.concatenate([x0, n, [l]])
        points.append(row)
    if points:
        last_row = points[-1]
        final_row = np.concatenate([last_row[:3], -last_row[3:6], [last_row[6]]])
        points.append(final_row)
    return np.vstack(points) if points else np.empty((0, 7))

def compute_errors(teach_df, repeat_df):
    # Compute the teach path matrix from the teach trajectory (using ECEF-X, Y, Z)
    teach_matrix = path_to_matrix(teach_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']])
    # Compute the signed lateral error for each point in the repeat trajectory relative to the teach path.
    errors = repeat_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].apply(
        lambda row: vtr_path.signed_distance_to_path(row.to_numpy(), teach_matrix), axis=1)
    repeat_df["PathError"] = errors
    return repeat_df

def plot_path(path_1, path_2,
                path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends,
                suptitle,
                colorbar_title):
    if not (len(path_1) == len(path_2) == len(path_1_omit_starts) ==
            len(path_1_omit_ends) == len(path_2_omit_starts) == len(path_2_omit_ends)):
        raise ValueError("All input lists must have the same length.")

    num_pairs = len(path_1)
    # For teach vs repeat group, if there are exactly two comparisons arrange them side-by-side.
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()

    all_abs_errors = []
    pairs_data = []  # Store tuples of (path_1_df, path_2_df) after trimming

    for idx, (p1, p2, p1_omit_start, p1_omit_end, p2_omit_start, p2_omit_end) in enumerate(
            zip(path_1, path_2, path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends)):
        p1_df = load_ecef_txt(p1)
        p2_df = load_ecef_txt(p2)

        # Omit specified measurements from path_1 and path_2 separately.
        if len(p1_df) > (p1_omit_start + p1_omit_end):
            p1_df = p1_df.iloc[p1_omit_start: len(p1_df) - p1_omit_end].reset_index(drop=True)
        if len(p2_df) > (p2_omit_start + p2_omit_end):
            p2_df = p2_df.iloc[p2_omit_start: len(p2_df) - p2_omit_end].reset_index(drop=True)

        # Compute errors for path_2 relative to path_1.
        p2_df = compute_errors(p1_df, p2_df)
        pairs_data.append((p1_df, p2_df))
        all_abs_errors.extend(p2_df["PathError"].abs().tolist())

        # Calculate RMSE and maximum lateral error for this pair.
        errors = p2_df["PathError"].to_numpy()
        rmse = np.sqrt(np.mean(errors**2))
        max_error = np.max(np.abs(errors))
        print(f"Path Pair {idx+1}: RMSE = {rmse:.3f} m, Max Lateral Error = {max_error:.3f} m")

    # Determine global color scale for absolute error.
    vmin = 0
    vmax = max(all_abs_errors) if all_abs_errors else 1

    # Plot each pair in its own subplot.
    for idx, (p1_df, p2_df) in enumerate(pairs_data):
        ax = axs[idx]
        # For the error plot, we rotate the p2 trajectory:
        x = -p2_df['ECEF-X'].to_numpy()  
        y = -p2_df['ECEF-Y'].to_numpy()
        abs_errors = p2_df['PathError'].abs().to_numpy()

        sc = ax.scatter(x, y, c=abs_errors, cmap='viridis', vmin=vmin, vmax=vmax, marker='o')
        ax.set_xlabel('ECEF-X (m)', fontsize=14)
        ax.set_ylabel('ECEF-Y (m)', fontsize=14)
        ax.set_title(f'', fontsize=16)
        ax.axis('equal')
        ax.grid(True, which='both', color='lightgrey', linestyle='-', linewidth=0.5, zorder=-1)
        ax.tick_params(axis='both', which='major', labelsize=12)

    # Remove any unused subplots.
    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])

    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.87, 0.15, 0.02, 0.7])
    cbar = fig.colorbar(sc, cax=cbar_ax)
    cbar.set_label(colorbar_title, fontsize=14)

    plt.suptitle(suptitle, fontsize=20)
    plt.show()

def plot_overlaid_trajectories(path_1, path_2,
                               path_1_omit_starts, path_1_omit_ends,
                               path_2_omit_starts, path_2_omit_ends,
                               suptitle="Overlaid Teach (Solid Blue) and Repeat (Dashed Red) Trajectories"):
    if not (len(path_1) == len(path_2) == len(path_1_omit_starts) ==
            len(path_1_omit_ends) == len(path_2_omit_starts) == len(path_2_omit_ends)):
        raise ValueError("All input lists must have the same length.")

    num_pairs = len(path_1)
    # For teach vs repeat group with two comparisons, force side-by-side: 1 row × 2 columns.
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()

    for idx, (p1, p2, p1_omit_start, p1_omit_end, p2_omit_start, p2_omit_end) in enumerate(
            zip(path_1, path_2, path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends)):
        p1_df = load_ecef_txt(p1)
        p2_df = load_ecef_txt(p2)

        # Omit specified measurements from each trajectory.
        if len(p1_df) > (p1_omit_start + p1_omit_end):
            p1_df = p1_df.iloc[p1_omit_start: len(p1_df) - p1_omit_end].reset_index(drop=True)
        if len(p2_df) > (p2_omit_start + p2_omit_end):
            p2_df = p2_df.iloc[p2_omit_start: len(p2_df) - p2_omit_end].reset_index(drop=True)

        ax = axs[idx]
        # Rotate both trajectories by multiplying by -1.
        p1_x = -p1_df['ECEF-X'].to_numpy()
        p1_y = -p1_df['ECEF-Y'].to_numpy()
        p2_x = -p2_df['ECEF-X'].to_numpy()
        p2_y = -p2_df['ECEF-Y'].to_numpy()

        # Plot the first trajectory (e.g. Teach) as a solid blue line.
        ax.plot(p1_x, p1_y, '-', color='blue', markersize=3, linewidth=2, label="Teach Trajectory")
        # Plot the second trajectory (e.g. Repeat) as a dashed red line.
        ax.plot(p2_x, p2_y, '--', color='red', markersize=3, linewidth=2, label="Repeat Trajectory")
        ax.set_xlabel('ECEF-X (m)', fontsize=14)
        ax.set_ylabel('ECEF-Y (m)', fontsize=14)
        ax.set_title(f'', fontsize=16)
        ax.axis('equal')
        ax.grid(True, which='both', color='lightgrey', linestyle='-', linewidth=0.5, zorder=-1)
        ax.tick_params(axis='both', which='major', labelsize=12)
        ax.legend(fontsize=12)

    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])

    plt.suptitle(suptitle, fontsize=20)
    plt.show()

def plot_overlaid_df_trajectories(df_list1, df_list2, suptitle="Overlaid Trajectories"):
    """
    Plots overlaid trajectories given as two lists of DataFrames.
    
    For each pair (df1, df2) in the input lists, df1 is plotted as a solid blue line
    (e.g. the aligned trajectory) and df2 is plotted as a dashed red line (e.g. the reference).
    It assumes each DataFrame has columns 'ECEF-X', 'ECEF-Y', and 'ECEF-Z'.
    """
    import matplotlib.pyplot as plt
    num_pairs = len(df_list1)
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()
    
    for idx, (df1, df2) in enumerate(zip(df_list1, df_list2)):
        ax = axs[idx]
        # Multiply by -1 to match the rotation used elsewhere.
        x1 = -df1['ECEF-X'].to_numpy()
        y1 = -df1['ECEF-Y'].to_numpy()
        x2 = -df2['ECEF-X'].to_numpy()
        y2 = -df2['ECEF-Y'].to_numpy()
        ax.plot(x1, y1, '-', color='blue', markersize=3, linewidth=2, label="Reference Trajectory")
        ax.plot(x2, y2, '--', color='red', markersize=3, linewidth=2, label="Aligned Trajectory")
        ax.set_xlabel("ECEF-X (m)", fontsize=14)
        ax.set_ylabel("ECEF-Y (m)", fontsize=14)
        ax.axis("equal")
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)

    # Remove titles from individual plots
    for ax in axs:
        ax.set_title("")

    # Remove any unused subplots
    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])

    # Add a single legend off to the side of the figure
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="center right", fontsize=12)

    plt.suptitle(suptitle, fontsize=20)
    plt.subplots_adjust(right=0.85)  # Adjust space for the legend
    plt.show()
    
def plot_path_df(df_list1, df_list2, suptitle="Error Plot", colorbar_title="Signed Error (m)"):
    """
    Computes and plots the signed lateral error for each pair of trajectories in df_list1 (teach) vs df_list2 (repeat).
    It uses your existing compute_errors function on the DataFrame pairs.
    """
    import matplotlib.pyplot as plt
    num_pairs = len(df_list1)
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()
    
    all_abs_errors = []
    pairs_data = []
    for idx, (df1, df2) in enumerate(zip(df_list1, df_list2)):
        df2_err = compute_errors(df1, df2)
        pairs_data.append((df1, df2_err))
        all_abs_errors.extend(df2_err["PathError"].abs().tolist())
    vmin = 0
    vmax = max(all_abs_errors) if all_abs_errors else 1
    
    for idx, (df1, df2_err) in enumerate(pairs_data):
        ax = axs[idx]
        # Rotate the repeat trajectory as in your other plots.
        x = -df2_err['ECEF-X'].to_numpy()
        y = -df2_err['ECEF-Y'].to_numpy()
        abs_errors = df2_err['PathError'].abs().to_numpy()
        sc = ax.scatter(x, y, c=abs_errors, cmap='viridis', vmin=vmin, vmax=vmax, marker='o')
        ax.set_xlabel("ECEF-X (m)", fontsize=14)
        ax.set_ylabel("ECEF-Y (m)", fontsize=14)
        ax.set_title(f"Error Plot Pair {idx+1}", fontsize=16)
        ax.axis("equal")
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    for j in range(idx+1, len(axs)):
        fig.delaxes(axs[j])
    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.87, 0.15, 0.02, 0.7])
    cbar = fig.colorbar(sc, cax=cbar_ax)
    cbar.set_label(colorbar_title, fontsize=14)
    plt.suptitle(suptitle, fontsize=20)

def icp_align(source_df, target_df, max_iterations=50, tolerance=1e-6):
        """
        Perform Iterative Closest Point (ICP) to align source_df to target_df.
        
        Parameters:
            source_df (pd.DataFrame): Source trajectory DataFrame with 'ECEF-X', 'ECEF-Y', 'ECEF-Z'.
            target_df (pd.DataFrame): Target trajectory DataFrame with 'ECEF-X', 'ECEF-Y', 'ECEF-Z'.
            max_iterations (int): Maximum number of ICP iterations.
            tolerance (float): Convergence tolerance for the transformation.
        
        Returns:
            pd.DataFrame: Aligned source DataFrame.
        """
        source_points = source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        target_points = target_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        
        prev_error = float('inf')
        for i in range(max_iterations):
            # Find the nearest neighbors in the target for each point in the source.
            nbrs = NearestNeighbors(n_neighbors=1).fit(target_points)
            distances, indices = nbrs.kneighbors(source_points)
            closest_points = target_points[indices.flatten()]
            
            # Compute the centroids of the source and target points.
            centroid_source = np.mean(source_points, axis=0)
            centroid_target = np.mean(closest_points, axis=0)
            
            # Center the points around their centroids.
            source_centered = source_points - centroid_source
            target_centered = closest_points - centroid_target
            
            # Compute the optimal rotation using Singular Value Decomposition (SVD).
            H = source_centered.T @ target_centered
            U, _, Vt = np.linalg.svd(H)
            R = Vt.T @ U.T
            
            # Ensure a proper rotation (det(R) = 1).
            if np.linalg.det(R) < 0:
                Vt[-1, :] *= -1
                R = Vt.T @ U.T
            
            # Compute the translation vector.
            t = centroid_target - R @ centroid_source
            
            # Apply the transformation to the source points.
            source_points = (R @ source_points.T).T + t
            
            # Check for convergence.
            mean_error = np.mean(distances)
            if abs(prev_error - mean_error) < tolerance:
                break
            prev_error = mean_error
        
        # Create a new DataFrame for the aligned source points.
        aligned_source_df = source_df.copy()
        aligned_source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = source_points
        return aligned_source_df

def plot_lateral_errors(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1,
                        aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2,
                        num_grid: int = 1000):
    """
    Plots all lateral path tracking errors for two groups on a single figure,
    resampled/interpolated onto a common along‑track grid, with markers at specified locations.
    """
    fig, axs = plt.subplots(1, 2, figsize=(16, 8), sharey=True)
    axs = axs.flatten()

    # Define marker locations for parking and mars loops
    parking_marks = np.array([
       2,  20, 50, 95, 145, 190, 240, 275, 315, 345, 370, 385
    ])  

    mars_marks = np.array([
       35, 75, 150, 165, 175, 210, 240, 270
    ])  

    for ax, (aligned_group, path_group, omit_starts, omit_ends, group_name, marks) in zip(
        axs,
        [(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1, parking_marks),
         (aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2, mars_marks)]
    ):
        runs = []
        # 1) collect cumdist & errors for each run
        for idx, (aligned_df, reference_path) in enumerate(zip(aligned_group, path_group)):
            ref = load_ecef_txt(reference_path)
            ref = ref.iloc[omit_starts[idx]:-omit_ends[idx]].reset_index(drop=True)
            ref = compute_errors(aligned_df, ref)
            errors = ref["PathError"].to_numpy()

            coords = ref[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
            segs = np.linalg.norm(np.diff(coords, axis=0), axis=1)
            cumdist = np.concatenate([[0], np.cumsum(segs)])

            runs.append((cumdist, errors))

        # 2) build a common grid from 0…max_length
        max_len = max(c[-1] for c, _ in runs)
        grid = np.linspace(0, max_len, num_grid)

        # 3) plot each run interpolated onto that grid
        for i, (cumdist, errors) in enumerate(runs):
            interp_err = np.interp(grid, cumdist, errors)
            ax.plot(grid, interp_err, linewidth=2, label=f"Path Pair {i+1}")

        # 4) Add markers at specified along-track distances
        for mark in marks:
            if mark <= max_len:  # Ensure the marker distance is within bounds
                ax.axvline(mark, color='k', linestyle='--', linewidth=1, label="Marker" if mark == marks[0] else None)

        ax.axhline(0, color="k", linestyle="--", linewidth=1)
        ax.set_xlabel("Along‑Track Distance (m)", fontsize=14)
        ax.set_ylabel("Lateral Error (m)", fontsize=14)
        ax.set_title(f"{group_name}: Lateral Errors", fontsize=16)
        ax.legend(fontsize=12)
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)

    plt.suptitle("Lateral Path Tracking Errors for Aligned Paths", fontsize=20)
    plt.tight_layout()
    plt.show()

def compute_and_plot_lateral_errors(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1,
                                    aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2,
                                    num_grid: int = 1000):
    """
    Computes RMSE/max error, then for each path pair resamples onto a common grid
    before plotting, and saves the raw PathError values as before.
    """
    for aligned_group, path_group, omit_starts, omit_ends, group_name in [
        (aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1),
        (aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2)
    ]:
        # collect all runs first
        runs = []
        for idx, (aligned_df, reference_path) in enumerate(zip(aligned_group, path_group)):
            ref = load_ecef_txt(reference_path)
            ref = ref.iloc[omit_starts[idx]:-omit_ends[idx]].reset_index(drop=True)
            ref = compute_errors(aligned_df, ref)
            errors = ref["PathError"].to_numpy()

            rmse = np.sqrt(np.mean(errors**2))
            max_err = np.max(np.abs(errors))
            print(f"{group_name} (ICP) - Pair {idx+1}: RMSE={rmse:.3f} m, Max={max_err:.3f} m")

            coords = ref[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
            segs = np.linalg.norm(np.diff(coords, axis=0), axis=1)
            cumdist = np.concatenate([[0], np.cumsum(segs)])

            runs.append((cumdist, errors))

            # export raw errors
            out_dir = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/ECEF_PTE_Data/"
            os.makedirs(out_dir, exist_ok=True)
            fn = f"NEW_TEST_{group_name.replace(' ','_').replace('(','').replace(')','').replace(':','').lower()}_lateral_error_path_pair_{idx+1}.txt"
            np.savetxt(os.path.join(out_dir, fn), errors, fmt="%.6f")
            print(f"  -> exported to {os.path.join(out_dir, fn)}")

        # common grid
        max_len = max(c[-1] for c, _ in runs)
        grid = np.linspace(0, max_len, num_grid)

        # plot all on one figure per group
        plt.figure(figsize=(10, 6))
        for i, (cumdist, errors) in enumerate(runs):
            interp_err = np.interp(grid, cumdist, errors)
            plt.plot(grid, interp_err, linewidth=2, label=f"Pair {i+1}")
        plt.axhline(0, color="k", linestyle="--", linewidth=1)
        plt.xlabel("Along‑Track Distance (m)", fontsize=14)
        plt.ylabel("Lateral Error (m)", fontsize=14)
        plt.title(f"{group_name}: Lateral Error (Interpolated)", fontsize=16)
        plt.legend(fontsize=12)
        plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
        plt.tight_layout()
        plt.show()

"""
import numpy as np

def plot_lateral_errors(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1,
                        aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2):

    fig, axs = plt.subplots(1, 2, figsize=(16, 8), sharey=True)
    axs = axs.flatten()
    for group_idx, (aligned_group, path_group, omit_starts, omit_ends, group_name, ax) in enumerate(
        [(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1, axs[0]),
         (aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2, axs[1])]):
        
        for idx, (aligned_df, reference_path) in enumerate(zip(aligned_group, path_group)):
            # load & trim reference, compute errors
            reference_df = load_ecef_txt(reference_path)
            reference_df = reference_df.iloc[omit_starts[idx]:-omit_ends[idx]].reset_index(drop=True)
            reference_df = compute_errors(aligned_df, reference_df)
            errors = reference_df["PathError"].to_numpy()

            # build along-track distance
            coords = reference_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
            segs = np.linalg.norm(np.diff(coords, axis=0), axis=1)
            cumdist = np.concatenate([[0], np.cumsum(segs)])

            ax.plot(cumdist, errors, label=f"Path Pair {idx+1}", linewidth=2)

        ax.axhline(0, color="black", linestyle="--", linewidth=1)
        ax.set_xlabel("Along‑Track Distance (m)", fontsize=14)
        ax.set_ylabel("Lateral Error (m)", fontsize=14)
        ax.set_title(f"{group_name}: Lateral Errors", fontsize=16)
        ax.legend(fontsize=12)
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)

    plt.suptitle("Lateral Path Tracking Errors for Aligned Paths", fontsize=20)
    plt.tight_layout()
    plt.show()


def compute_and_plot_lateral_errors(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1,
                                    aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2):

    for group_idx, (aligned_group, path_group, omit_starts, omit_ends, group_name) in enumerate(
        [(aligned_group1, path_group1, omit_starts1, omit_ends1, group_name1),
         (aligned_group2, path_group2, omit_starts2, omit_ends2, group_name2)]):

        for idx, (aligned_df, reference_path) in enumerate(zip(aligned_group, path_group)):
            # load & trim reference, compute errors
            reference_df = load_ecef_txt(reference_path)
            reference_df = reference_df.iloc[omit_starts[idx]:-omit_ends[idx]].reset_index(drop=True)
            reference_df = compute_errors(aligned_df, reference_df)
            errors = reference_df["PathError"].to_numpy()

            # metrics
            rmse = np.sqrt(np.mean(errors**2))
            max_error = np.max(np.abs(errors))
            print(f"{group_name} (ICP Aligned) - Path Pair {idx+1}: RMSE = {rmse:.3f} m, Max = {max_error:.3f} m")

            # compute along-track distance
            coords = reference_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
            segs = np.linalg.norm(np.diff(coords, axis=0), axis=1)
            cumdist = np.concatenate([[0], np.cumsum(segs)])

            # plot
            plt.figure(figsize=(10, 6))
            plt.plot(cumdist,
                     errors,
                     label="Lateral Error",
                     color="blue", linewidth=2)
            plt.axhline(0, color="black", linestyle="--", linewidth=1)
            plt.xlabel("Along‑Track Distance (m)", fontsize=14)
            plt.ylabel("Lateral Error (m)", fontsize=14)
            plt.title(f"{group_name} - Path Pair {idx+1}: Lateral Error", fontsize=16)
            plt.legend(fontsize=12)
            plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)

            # save raw error values (unchanged)
            out_dir = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/ECEF_PTE_Data/"
            os.makedirs(out_dir, exist_ok=True)
            fn = f"NEW_TEST_{group_name.replace(' ', '_').replace('(', '').replace(')', '').replace(':','').lower()}_lateral_error_path_pair_{idx+1}.txt"
            np.savetxt(os.path.join(out_dir, fn), errors, fmt="%.6f")
            print(f"Exported lateral error to {os.path.join(out_dir, fn)}")

    plt.show()

"""

def get_marker_xy_from_times(
    raw_file: str,
    gt_file: str,
    start_time: float,
    marker_times: list[float],
) -> list[tuple[float, float]]:
    # 1) Load raw log; first column is epoch, then ECEF-X/Y/Z
    raw_df = pd.read_csv(
        raw_file,
        sep=r'\s+',
        header=None,
        skiprows=16,
        names=['epoch','ECEF-X','ECEF-Y','ECEF-Z'],
    )
    raw_df['epoch'] = pd.to_numeric(raw_df['epoch'], errors='coerce')
    raw_df = raw_df.dropna(subset=['epoch']).reset_index(drop=True)

    # 2) Rebase timestamps so they start exactly at start_time
    orig0 = raw_df['epoch'].iloc[0]
    raw_df['epoch'] = float(start_time) + (raw_df['epoch'] - orig0)

    # 3) Compute relative time since start (0.0, 0.1, 0.2, …)
    raw_df['t_rel'] = raw_df['epoch'] - float(start_time)

    # 4) Find each marker’s closest row
    marker_xy = []
    for i, mt in enumerate(marker_times, 1):
        offset = float(mt) - float(start_time)
        idx = raw_df['t_rel'].sub(offset).abs().idxmin()
        matched_trel = raw_df.loc[idx, 't_rel']
        x, y = raw_df.loc[idx, ['ECEF-X','ECEF-Y']]
        marker_xy.append((x, y))
        print(f"Marker {i:2d}: t_rel target={offset:.3f}s → idx={idx}, actual t_rel={matched_trel:.3f}s → (x,y)=({x:.6f},{y:.6f})")

    # 5) Plot GT path + all markers
    gt_df = load_ecef_txt(gt_file)
    # convert Series → numpy arrays before plotting
    x_gt = -gt_df['ECEF-X'].to_numpy()
    y_gt = -gt_df['ECEF-Y'].to_numpy()
    x_mark = [-x for x,_ in marker_xy]
    y_mark = [-y for _,y in marker_xy]

    plt.figure(figsize=(8,6))
    plt.plot(x_gt, y_gt, '-', label='GT Path')
    plt.scatter(x_mark, y_mark, c='red', s=50, label='Markers')
    plt.xlabel('ECEF-X (m)')
    plt.ylabel('ECEF-Y (m)')
    plt.title('GT Path with Detected Marker Locations')
    plt.legend()
    plt.grid(True)
    plt.show()

    return marker_xy

def find_marker_positions(df: pd.DataFrame,
                          marker_xy: list[tuple[float, float]],
                          x_col: str = 'ECEF-X',
                          y_col: str = 'ECEF-Y'
) -> tuple[list[int], list[tuple[float, float]], list[float]]:
    """
    For each (x,y) in `marker_xy`, find the nearest (x_col,y_col) in df.
    Returns three lists: indices, positions, and 2D distances.
    """
    pts = df[[x_col, y_col]].to_numpy()
    idxs = []
    positions = []
    dists = []
    for mx, my in marker_xy:
        d = np.linalg.norm(pts - np.array([mx, my]), axis=1)
        i = int(np.argmin(d))
        idxs.append(i)
        px, py = pts[i]
        positions.append((px, py))
        dists.append(float(d[i]))
    return idxs, positions, dists

def detect_marker_candidates(
    df,
    heading_thresh: float = 0.2,
    min_jolt_length: int = 3
) -> list[int]:
    """
    Detects “jolts” in a 2D path by looking for runs of large heading changes.
    Returns one candidate index (the start) per jolt run.

    Parameters:
      df               – DataFrame with 'ECEF-X','ECEF-Y'
      heading_thresh   – min Δheading (rad) to count as “in a jolt”
      min_jolt_length  – min number of consecutive threshold‐crossings to call a jolt

    Returns:
      List of row‐indices in `df` where each jolt begins.
    """
    xs = df['ECEF-X'].to_numpy()
    ys = df['ECEF-Y'].to_numpy()

    # 1) segment headings
    dx = np.diff(xs)
    dy = np.diff(ys)
    angles = np.arctan2(dy, dx)

    # 2) heading‐change between consecutive segments
    da = np.abs(np.diff(angles))
    da = np.minimum(da, 2*np.pi - da)  # wrap

    # 3) boolean mask where change > threshold
    jolt_mask = da > heading_thresh  # length = len(df)-2

    # 4) find runs of True in jolt_mask
    runs = []
    in_run = False
    for i, v in enumerate(jolt_mask):
        if v and not in_run:
            run_start = i
            in_run = True
        elif not v and in_run:
            runs.append((run_start, i-1))
            in_run = False
    if in_run:
        runs.append((run_start, len(jolt_mask)-1))

    # 5) pick only runs ≥ min_jolt_length and map back to df indices
    candidates = [
        run_start + 1
        for run_start, run_end in runs
        if (run_end - run_start + 1) >= min_jolt_length
    ]

    return candidates

def confirm_markers(df, candidates):
    """
    Plot trajectory & candidates, let user click to confirm.
    Returns list of confirmed indices.
    """
    # rotated coords for plotting
    x = -df['ECEF-X'].to_numpy()
    y = -df['ECEF-Y'].to_numpy()
    cand_x = x[candidates]
    cand_y = y[candidates]

    fig, ax = plt.subplots(figsize=(8,6))
    ax.plot(x, y, '-', color='grey', alpha=0.5)
    sc = ax.scatter(cand_x, cand_y, c='red', s=80, label='candidates')
    ax.set_title("Click to confirm markers; hit Enter when done")
    ax.set_xlabel("ECEF-X (m)"); ax.set_ylabel("ECEF-Y (m)")
    ax.axis('equal'); ax.grid(True)
    fig.canvas.draw()

    # let user click arbitrarily many times, then press Enter
    clicks = plt.ginput(n=0, timeout=0)
    plt.close(fig)

    confirmed = set()
    for cx, cy in clicks:
        # find nearest candidate
        d2 = (cand_x - cx)**2 + (cand_y - cy)**2
        i = np.argmin(d2)
        confirmed.add(candidates[i])

    return sorted(confirmed)

def nominal_average_assessment(path_list, omit_starts, omit_ends, group_name):
    # 1) Trim & load
    runs = []
    for idx, p in enumerate(path_list):
        df = load_ecef_txt(p)
        if len(df) > (omit_starts[idx] + omit_ends[idx]):
            df = df.iloc[omit_starts[idx] : len(df) - omit_ends[idx]].reset_index(drop=True)
        runs.append(df)
    # 2) Build per-run cumdist & XY
    cumdists = []
    run_xy   = []
    for df in runs:
        pts = df[['ECEF-X','ECEF-Y']].to_numpy()
        # along-track distances
        segs = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        cd   = np.concatenate([[0], np.cumsum(segs)])
        cumdists.append(cd)
        run_xy.append(pts)
    # 3) Common grid
    common_max = min(cd[-1] for cd in cumdists)
    grid       = np.linspace(0, common_max, 1000)
    # 4) Resample each run onto that grid
    resampled = []
    for cd, pts in zip(cumdists, run_xy):
        xs = np.interp(grid, cd, pts[:,0])
        ys = np.interp(grid, cd, pts[:,1])
        resampled.append(np.vstack([xs, ys]).T)
    resampled = np.stack(resampled, axis=0)  # shape (N_runs, N_grid, 2)
    # 5) Nominal path = mean XY at each grid point
    nominal_xy = resampled.mean(axis=0)      # (N_grid,2)
    # 6) Compute per-run signed lateral error to nominal:
    #    a) tangent & normal at each nominal point
    tangents = np.gradient(nominal_xy, axis=0)          # d(x,y)/ds
    norms    = np.linalg.norm(tangents, axis=1, keepdims=True)
    tangents[norms[:,0]>0] /= norms[norms[:,0]>0]       # normalize
    normals  = np.column_stack([-tangents[:,1], tangents[:,0]])  # rotate 90°
    #    b) for each run, error = dot( (run - nominal), normal )
    errors = []
    for run_pts in resampled:
        diffs = run_pts - nominal_xy
        err   = np.einsum('ij,ij->i', diffs, normals)
        errors.append(err)
    errors = np.stack(errors, axis=0)  # shape (N_runs, N_grid)
    abs_err = np.abs(errors)
    rmse_pt = np.sqrt((errors**2).mean(axis=0))  # RMSE at each grid point
    mean_rmse = rmse_pt.mean()                  # overall
    max_dev   = abs_err.max()                   # worst across all runs/grid
    print(f"\n*** {group_name} (Nominal-Average) ***")
    print(f" Overall RMSE = {mean_rmse:.3f} m")
    print(f" Max lateral deviation = {max_dev:.3f} m")
    # 7) Plot nominal path colored by rmse_pt, mark worst spot
    fig, ax = plt.subplots(figsize=(8,6))
    sc = ax.scatter(
        -nominal_xy[:,0],         # rotate for your plotting convention
        -nominal_xy[:,1],
        c=rmse_pt, cmap='viridis', s=15 
    )
    cbar = fig.colorbar(sc, ax=ax)
    cbar.set_label("GPS-Measured Pointwise RMSE over all Repeats (m)")
    ax.set_title(f"{group_name}: Nominal-Average Path RMSE")
    ax.axis('equal')
    ax.grid(True, linestyle='--', linewidth=0.5)
    ax.legend()
    plt.show()


##################### MAIN FUNCTION #####################

def main():
    # Full lists of file paths for teach and repeat trajectories.
    path_1 = [ # MESH PATH FOR PARKING AND DOME
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_DJI_mesh_path_ecef.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2pppECEF_novatel_data_2025_02_25-04_46_49.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2pppECEF_novatel_data_2025_02_25-04_46_49.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2pppECEF_novatel_data_2025_02_25-04_46_49.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1pppECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1pppECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1pppECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1pppECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1pppECEF_novatel_data_2025_02_24-14_26_12.txt",
    ]

    path_2 = [ # REPEAT PATHS FOR PARKING AND DOME
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_34_37.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_13_43.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_34_07.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_56_26.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_08_52.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_22_14.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_33_40.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_45_29.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_56_58.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2ppkECEF_novatel_data_2025_02_25-04_46_49.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2ppkECEF_novatel_data_2025_02_25-04_36_36.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2ppkECEF_novatel_data_2025_02_25-05_09_40.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-14_16_13.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-14_38_29.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-16_14_54.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-16_22_52.txt",
]

    path_1_omit_starts = [46, 46, 46, 46, 46, 46,       57, 57, 57, 57, 57, 57,               200, 200 ,200,      280, 280, 280, 280, 280] 
    path_1_omit_ends   = [51, 51, 51, 51, 51, 51,       105, 105, 105, 105, 105, 105,         350, 350, 350,      405, 405, 405, 405, 405]
    # And specify omission for the second dataset.
    path_2_omit_starts = [941, 718, 776, 749, 762, 720,     210, 133, 137, 133, 129, 129,     219, 141, 261,     366, 295, 310, 290, 282] 
    path_2_omit_ends   = [800, 809, 877, 749, 819, 810,     43,  58,  92,  56,  40,  40,      363, 420, 352,     400, 425,  417,  532,  422] #top

    # Split data into four groups:
    # First five comparisons represent the first group.
    path_1_group1 = path_1[:5]
    path_2_group1 = path_2[:5]
    path_1_omit_starts_group1 = path_1_omit_starts[:5]
    path_1_omit_ends_group1 = path_1_omit_ends[:5]
    path_2_omit_starts_group1 = path_2_omit_starts[:5]
    path_2_omit_ends_group1 = path_2_omit_ends[:5]

    # The next five comparisons represent the second group.
    path_1_group2 = path_1[6:11]
    path_2_group2 = path_2[6:11]
    path_1_omit_starts_group2 = path_1_omit_starts[6:11]
    path_1_omit_ends_group2 = path_1_omit_ends[6:11]
    path_2_omit_starts_group2 = path_2_omit_starts[6:11]
    path_2_omit_ends_group2 = path_2_omit_ends[6:11]

    # The next five comparisons represent the third group.
    path_1_group3 = path_1[12:15]
    path_2_group3 = path_2[12:15]
    path_1_omit_starts_group3 = path_1_omit_starts[12:15]
    path_1_omit_ends_group3 = path_1_omit_ends[12:15]
    path_2_omit_starts_group3 = path_2_omit_starts[12:15]
    path_2_omit_ends_group3 = path_2_omit_ends[12:15]

    # The remaining comparisons represent the fourth group.
    path_1_group4 = path_1[15:]
    path_2_group4 = path_2[15:]
    path_1_omit_starts_group4 = path_1_omit_starts[15:]
    path_1_omit_ends_group4 = path_1_omit_ends[15:]
    path_2_omit_starts_group4 = path_2_omit_starts[15:]
    path_2_omit_ends_group4 = path_2_omit_ends[15:]

    # Plot all second paths over each other for group 1, including the first path in path_1
    plt.figure(figsize=(10, 8))
    for idx, path in enumerate(path_2_group1):
        df = load_ecef_txt(path).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True)
        x = -df['ECEF-X'].to_numpy()
        y = -df['ECEF-Y'].to_numpy()
        plt.plot(x, y, '--', label=f"Path 2-{idx+1}", linewidth=2)

    # Add the first path in path_1
    df_first = load_ecef_txt(path_1_group1[0]).iloc[path_1_omit_starts_group1[0]:-path_1_omit_ends_group1[0]].reset_index(drop=True)
    x_first = -df_first['ECEF-X'].to_numpy()
    y_first = -df_first['ECEF-Y'].to_numpy()
    plt.plot(x_first, y_first, '-', label="Path 1-1 (First Path)", linewidth=2, color='blue')
    plt.xlabel("ECEF-X (m)", fontsize=14)
    plt.ylabel("ECEF-Y (m)", fontsize=14)
    plt.title("Group 1: Overlaid Repeat Paths (Parking Loop)", fontsize=16)
    plt.legend(fontsize=12)
    plt.axis("equal")
    plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    #plt.show()

    # Plot all second paths over each other for group 2, including the first path in path_1
    plt.figure(figsize=(10, 8))
    for idx, path in enumerate(path_2_group2):
        df = load_ecef_txt(path).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True)
        x = -df['ECEF-X'].to_numpy()
        y = -df['ECEF-Y'].to_numpy()
        plt.plot(x, y, '--', label=f"Path 2-{idx+1}", linewidth=2)

    # Add the first path in path_1
    df_first = load_ecef_txt(path_1_group2[0]).iloc[path_1_omit_starts_group2[0]:-path_1_omit_ends_group2[0]].reset_index(drop=True)
    x_first = -df_first['ECEF-X'].to_numpy()
    y_first = -df_first['ECEF-Y'].to_numpy()
    plt.plot(x_first, y_first, '-', label="Path 1-1 (First Path)", linewidth=2, color='blue')
    plt.xlabel("ECEF-X (m)", fontsize=14)
    plt.ylabel("ECEF-Y (m)", fontsize=14)
    plt.title("Group 2: Overlaid Repeat Paths (Dome Loop)", fontsize=16)
    plt.legend(fontsize=12)
    plt.axis("equal")
    plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    #plt.show()

    # Plot all second paths over each other for group 3, including the first path in path_1
    plt.figure(figsize=(10, 8))
    for idx, path in enumerate(path_2_group3):
        df = load_ecef_txt(path).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True)
        x = -df['ECEF-X'].to_numpy()
        y = -df['ECEF-Y'].to_numpy()
        plt.plot(x, y, '--', label=f"Path 2-{idx+1}", linewidth=2)

    # Add the first path in path_1
    df_first = load_ecef_txt(path_1_group3[0]).iloc[path_1_omit_starts_group3[0]:-path_1_omit_ends_group3[0]].reset_index(drop=True)
    x_first = -df_first['ECEF-X'].to_numpy()
    y_first = -df_first['ECEF-Y'].to_numpy()
    plt.plot(x_first, y_first, '-', label="Path 1-1 (First Path)", linewidth=2, color='blue')
    plt.xlabel("ECEF-X (m)", fontsize=14)
    plt.ylabel("ECEF-Y (m)", fontsize=14)
    plt.title("Group 3: Overlaid Repeat Paths", fontsize=16)
    plt.legend(fontsize=12)
    plt.axis("equal")
    plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    #plt.show()

    # Plot all second paths over each other for group 4, including the first path in path_1
    plt.figure(figsize=(10, 8))
    for idx, path in enumerate(path_2_group4):
        df = load_ecef_txt(path).iloc[path_2_omit_starts_group4[idx]:-path_2_omit_ends_group4[idx]].reset_index(drop=True)
        x = -df['ECEF-X'].to_numpy()
        y = -df['ECEF-Y'].to_numpy()
        plt.plot(x, y, '--', label=f"Path 2-{idx+1}", linewidth=2)

    # Add the first path in path_1
    df_first = load_ecef_txt(path_1_group4[0]).iloc[path_1_omit_starts_group4[0]:-path_1_omit_ends_group4[0]].reset_index(drop=True)
    x_first = -df_first['ECEF-X'].to_numpy()
    y_first = -df_first['ECEF-Y'].to_numpy()
    plt.plot(x_first, y_first, '-', label="Path 1-1 (First Path)", linewidth=2, color='blue')
    plt.xlabel("ECEF-X (m)", fontsize=14)
    plt.ylabel("ECEF-Y (m)", fontsize=14)
    plt.title("Group 4: Overlaid Repeat Paths", fontsize=16)
    plt.legend(fontsize=12)
    plt.axis("equal")
    plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    #plt.show()

    # # Plot overlaid trajectories for group 1 (repeat vs repeat).
    # plot_overlaid_trajectories(path_1_group1, path_2_group1, path_1_omit_starts_group1, path_1_omit_ends_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, suptitle="Overlaid Pseudo-Gazebo-GPS vs Real Repeat Trajectories for Parking Loop")
   
    # # Plot overlaid trajectories for group 2 (teach vs repeat).
    # plot_overlaid_trajectories(path_1_group2, path_2_group2, path_1_omit_starts_group2, path_1_omit_ends_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, suptitle="Overlaid Pseudo-Gazebo-GPS vs Real Repeat Trajectories for Mars Dome Loop")
    
    # # --- Align paths for all comparisons in group 1 and group 2 ---
    # aligned_paths_group1 = [] # PARKING
    # for idx in range(len(path_1_group1)):
    #     aligned_path = align_path(path_1_group1[idx], path_2_group1[idx],
    #                               omit_start1=path_1_omit_starts_group1[idx],
    #                               omit_end1=path_1_omit_ends_group1[idx],
    #                               omit_start2=path_2_omit_starts_group1[idx],
    #                               omit_end2=path_2_omit_ends_group1[idx])
    #     aligned_paths_group1.append(aligned_path)

    # aligned_paths_group2 = [] # DOME
    # for idx in range(len(path_1_group2)):
    #     aligned_path = align_path(path_1_group2[idx], path_2_group2[idx],
    #                               omit_start1=path_1_omit_starts_group2[idx],
    #                               omit_end1=path_1_omit_ends_group2[idx],
    #                               omit_start2=path_2_omit_starts_group2[idx],
    #                               omit_end2=path_2_omit_ends_group2[idx])
    #     aligned_paths_group2.append(aligned_path)

    # # Align paths for all comparisons in group 3 and group 4
    # aligned_paths_group3 = []  # Group 3
    # for idx in range(len(path_1_group3)):
    #     aligned_path = align_path(path_1_group3[idx], path_2_group3[idx],
    #                               omit_start1=path_1_omit_starts_group3[idx],
    #                               omit_end1=path_1_omit_ends_group3[idx],
    #                               omit_start2=path_2_omit_starts_group3[idx],
    #                               omit_end2=path_2_omit_ends_group3[idx])
    #     aligned_paths_group3.append(aligned_path)

    # aligned_paths_group4 = []  # Group 4
    # for idx in range(len(path_1_group4)):
    #     aligned_path = align_path(path_1_group4[idx], path_2_group4[idx],
    #                               omit_start1=path_1_omit_starts_group4[idx],
    #                               omit_end1=path_1_omit_ends_group4[idx],
    #                               omit_start2=path_2_omit_starts_group4[idx],
    #                               omit_end2=path_2_omit_ends_group4[idx])
    #     aligned_paths_group4.append(aligned_path)
    
    # Make DataFrames for the reference datasets in group 1 and group 2 (the repeat GPS), load and trim the corresponding path_2 files as done above.
    # group4_path2 = []
    # for idx, path in enumerate(path_2_group1 + path_2_group2):
    #     omit_start = (path_2_omit_starts_group1 + path_2_omit_starts_group2)[idx]
    #     omit_end = (path_2_omit_ends_group1 + path_2_omit_ends_group2)[idx]
    #     df_path2 = load_ecef_txt(path)
    #     if len(df_path2) > (omit_start + omit_end):
    #         df_path2 = df_path2.iloc[omit_start:len(df_path2) - omit_end].reset_index(drop=True)
    #     group4_path2.append(df_path2)
    
    # Plot the overlaid trajectories for 
    #plot_overlaid_df_trajectories(group4_path1, group4_path2, suptitle="Overlaid Manually Aligned vs Reference Trajectories")
    
    # Perform ICP alignment for group 1 and group 2 trajectories.
    aligned_group1_path1 = []
    for idx, (df1, df2) in enumerate(zip(path_1_group1, path_2_group1)):
        df1_trimmed = load_ecef_txt(df1).iloc[path_1_omit_starts_group1[idx]:-path_1_omit_ends_group1[idx]].reset_index(drop=True)
        df2_trimmed = load_ecef_txt(df2).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True)
        aligned_df1 = icp_align(df1_trimmed, df2_trimmed)
        aligned_group1_path1.append(aligned_df1)

    aligned_group2_path1 = []
    for idx, (df1, df2) in enumerate(zip(path_1_group2, path_2_group2)):
        df1_trimmed = load_ecef_txt(df1).iloc[path_1_omit_starts_group2[idx]:-path_1_omit_ends_group2[idx]].reset_index(drop=True)
        df2_trimmed = load_ecef_txt(df2).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True)
        aligned_df1 = icp_align(df1_trimmed, df2_trimmed)
        aligned_group2_path1.append(aligned_df1)

    # Perform ICP alignment for group 3 and group 4 trajectories.
    aligned_group3_path1 = []
    for idx, (df1, df2) in enumerate(zip(path_1_group3, path_2_group3)):
        df1_trimmed = load_ecef_txt(df1).iloc[path_1_omit_starts_group3[idx]:-path_1_omit_ends_group3[idx]].reset_index(drop=True)
        df2_trimmed = load_ecef_txt(df2).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True)
        aligned_df1 = icp_align(df1_trimmed, df2_trimmed)
        aligned_group3_path1.append(aligned_df1)

    aligned_group4_path1 = []
    for idx, (df1, df2) in enumerate(zip(path_1_group4, path_2_group4)):
        df1_trimmed = load_ecef_txt(df1).iloc[path_1_omit_starts_group4[idx]:-path_1_omit_ends_group4[idx]].reset_index(drop=True)
        df2_trimmed = load_ecef_txt(df2).iloc[path_2_omit_starts_group4[idx]:-path_2_omit_ends_group4[idx]].reset_index(drop=True)
        aligned_df1 = icp_align(df1_trimmed, df2_trimmed)
        aligned_group4_path1.append(aligned_df1)

    # # Plot the ICP-aligned trajectories for groups 1 and 2.
    # plot_overlaid_df_trajectories(aligned_group1_path1, 
    #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group1)], 
    #                               suptitle="Group 1: ICP-Aligned vs Reference Trajectories (Parking Loop)")

    # plot_overlaid_df_trajectories(aligned_group2_path1, 
    #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group2)], 
    #                               suptitle="Group 2: ICP-Aligned vs Reference Trajectories (Dome Loop)")

    # # Plot the ICP-aligned trajectories for groups 3 and 4.
    # plot_overlaid_df_trajectories(aligned_group3_path1, 
    #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group3)], 
    #                               suptitle="Group 3: ICP-Aligned vs Reference Trajectories")

    # plot_overlaid_df_trajectories(aligned_group4_path1, 
    #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group4[idx]:-path_2_omit_ends_group4[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group4)], 
    #                               suptitle="Group 4: ICP-Aligned vs Reference Trajectories")
    
    # # Plot the signed lateral error (signed-distance) plots for ICP-aligned trajectories in group 1 and group 2.
    # plot_path_df(aligned_group1_path1, 
    #              [load_ecef_txt(p).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group1)], 
    #              suptitle="Group 1: Signed Distance Error for ICP-Aligned Trajectories (Parking Loop)", 
    #              colorbar_title="Signed Lateral Error (m)")

    # plot_path_df(aligned_group2_path1, 
    #              [load_ecef_txt(p).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group2)], 
    #              suptitle="Group 2: Signed Distance Error for ICP-Aligned Trajectories (Dome Loop)", 
    #              colorbar_title="Signed Lateral Error (m)")
    #             # Plot the signed lateral error (signed-distance) plots for ICP-aligned trajectories in group 3 and group 4.
    
    # plot_path_df(aligned_group3_path1, 
    #              [load_ecef_txt(p).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group3)], 
    #              suptitle="Group 3: Signed Distance Error for ICP-Aligned Trajectories", 
    #              colorbar_title="Signed Lateral Error (m)")

    # plot_path_df(aligned_group4_path1, 
    #              [load_ecef_txt(p).iloc[path_2_omit_starts_group4[idx]:-path_2_omit_ends_group4[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group4)], 
    #              suptitle="Group 4: Signed Distance Error for ICP-Aligned Trajectories", 
    #              colorbar_title="Signed Lateral Error (m)")
    
    #compute_and_plot_lateral_errors(
    #    aligned_group1_path1, path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, "Group 1 (Parking Loop)",
    #    aligned_group2_path1, path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, "Group 2 (Dome Loop)"
    #)

    # plot_lateral_errors(
    #     aligned_group1_path1, path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, "Group 1 (Parking Loop)",
    #     aligned_group2_path1, path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, "Group 2 (Dome Loop)"
    # )

    '''
    def select_marks(paths, omit_starts, omit_ends, group_name, num_marks):

        marks = []

        def onclick(event):
            if event.button == 1:  # Left mouse button
                marks.append((event.xdata, event.ydata))
                print(f"Mark {len(marks)}: ({event.xdata}, {event.ydata})")
                if len(marks) == num_marks:
                    plt.close()

        for idx, path in enumerate(paths):
            df = load_ecef_txt(path).iloc[omit_starts[idx]:-omit_ends[idx]].reset_index(drop=True)
            x = -df['ECEF-X'].to_numpy()
            y = -df['ECEF-Y'].to_numpy()

            fig, ax = plt.subplots(figsize=(10, 8))
            ax.plot(x, y, '-', label=f"Path {idx+1}", linewidth=2)
            ax.set_title(f"{group_name}: Select {num_marks} Marks for Path {idx+1}", fontsize=16)
            ax.set_xlabel("ECEF-X (m)", fontsize=14)
            ax.set_ylabel("ECEF-Y (m)", fontsize=14)
            ax.axis("equal")
            ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
            fig.canvas.mpl_connect('button_press_event', onclick)
            plt.show()

        return marks

    def icp_with_marks(source_df, target_marks, max_iterations=50, tolerance=1e-6):

        source_points = source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        target_points = np.array(target_marks)

        prev_error = float('inf')
        for i in range(max_iterations):
            # Find the nearest neighbors in the target for each point in the source.
            nbrs = NearestNeighbors(n_neighbors=1).fit(target_points)
            distances, indices = nbrs.kneighbors(source_points)
            closest_points = target_points[indices.flatten()]

            # Compute the centroids of the source and target points.
            centroid_source = np.mean(source_points, axis=0)
            centroid_target = np.mean(closest_points, axis=0)

            # Center the points around their centroids.
            source_centered = source_points - centroid_source
            target_centered = closest_points - centroid_target

            # Compute the optimal rotation using Singular Value Decomposition (SVD).
            H = source_centered.T @ target_centered
            U, _, Vt = np.linalg.svd(H)
            R = Vt.T @ U.T

            # Ensure a proper rotation (det(R) = 1).
            if np.linalg.det(R) < 0:
                Vt[-1, :] *= -1
                R = Vt.T @ U.T

            # Compute the translation vector.
            t = centroid_target - R @ centroid_source

            # Apply the transformation to the source points.
            source_points = (R @ source_points.T).T + t

            # Check for convergence.
            mean_error = np.mean(distances)
            if abs(prev_error - mean_error) < tolerance:
                break
            prev_error = mean_error

        # Create a new DataFrame for the aligned source points.
        aligned_source_df = source_df.copy()
        aligned_source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = source_points
        return aligned_source_df

    # Select marks for group 1 and group 2
    marks_group1 = select_marks(path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, "Group 1 (Parking Loop)", 12)
    marks_group2 = select_marks(path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, "Group 2 (Dome Loop)", 8)

    # Perform ICP alignment using the selected marks
    final_aligned_group1 = []
    for idx, path in enumerate(path_1_group1):
        df = load_ecef_txt(path).iloc[path_1_omit_starts_group1[idx]:-path_1_omit_ends_group1[idx]].reset_index(drop=True)
        aligned_df = icp_with_marks(df, marks_group1)
        final_aligned_group1.append(aligned_df)

    final_aligned_group2 = []
    for idx, path in enumerate(path_1_group2):
        df = load_ecef_txt(path).iloc[path_1_omit_starts_group2[idx]:-path_1_omit_ends_group2[idx]].reset_index(drop=True)
        aligned_df = icp_with_marks(df, marks_group2)
        final_aligned_group2.append(aligned_df)

    # Plot the final alignment for group 1 and group 2
    plot_overlaid_df_trajectories(final_aligned_group1, 
                                  [load_ecef_txt(p).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group1)], 
                                  suptitle="Final Alignment for Group 1 (Parking Loop)")

    plot_overlaid_df_trajectories(final_aligned_group2, 
                                  [load_ecef_txt(p).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group2)], 
                                  suptitle="Final Alignment for Group 2 (Dome Loop)")
    '''
    
    # Compute and print RMSE and max error for each path comparison in all groups
    for group_name, aligned_paths, reference_paths, omit_starts, omit_ends in [
        ("Group 1 (Parking Loop)", aligned_group1_path1, path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1),
        ("Group 2 (Dome Loop)", aligned_group2_path1, path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2),
        ("Group 3", aligned_group3_path1, path_2_group3, path_2_omit_starts_group3, path_2_omit_ends_group3),
        ("Group 4", aligned_group4_path1, path_2_group4, path_2_omit_starts_group4, path_2_omit_ends_group4)
    ]:
        print(f"\n=== {group_name} ===")
        for idx, (aligned_df, reference_path) in enumerate(zip(aligned_paths, reference_paths), start=1):
            ref_df = load_ecef_txt(reference_path).iloc[omit_starts[idx - 1]:-omit_ends[idx - 1]].reset_index(drop=True)
            ref_df = compute_errors(aligned_df, ref_df)
            errors = ref_df["PathError"].to_numpy()
            rmse = np.sqrt(np.mean(errors**2))
            max_error = np.max(np.abs(errors))
            print(f"Path Pair {idx}: RMSE = {rmse:.3f} m, Max Error = {max_error:.3f} m")

    ## Implement pairwise RMSE and max error calculation HERE
    for group_name, path_list, omit_starts, omit_ends in [
        ("Group 1 (Parking Loop)", path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1),
        ("Group 2 (Dome Loop)",   path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2),
        ("Group 3 (UTP2 Loop)", path_2_group3, path_2_omit_starts_group3, path_2_omit_ends_group3),
        ("Group 4 (UTP1 Loop)", path_2_group4, path_2_omit_starts_group4, path_2_omit_ends_group4)
    ]:
        # Load & trim all runs for this group
        trimmed_runs = []
        for idx, p in enumerate(path_list):
            df = load_ecef_txt(p)
            if len(df) > (omit_starts[idx] + omit_ends[idx]):
                df = df.iloc[omit_starts[idx] : len(df) - omit_ends[idx]].reset_index(drop=True)
            trimmed_runs.append(df)

        N = len(trimmed_runs)
        rmse_mat = np.zeros((N, N))
        max_mat  = np.zeros((N, N))

        print(f"\n--- Pairwise RMSE / Max Error for {group_name} ---")
        for i, j in itertools.combinations(range(N), 2):
            # compute errors of run j relative to run i
            df_i = trimmed_runs[i]
            df_j = trimmed_runs[j]
            dfj_err = compute_errors(df_i, df_j)
            errs = dfj_err["PathError"].to_numpy()
            rmse    = np.sqrt(np.mean(errs**2))
            max_err = np.max(np.abs(errs))

            rmse_mat[i, j] = rmse_mat[j, i] = rmse
            max_mat [i, j] = max_mat [j, i] = max_err

            print(f"  {group_name} — Run {i+1} vs {j+1}:  RMSE = {rmse:.3f} m,  Max = {max_err:.3f} m")

        # Trim & load all runs
        runs = []
        for idx, p in enumerate(path_list):
            df = load_ecef_txt(p)
            if len(df) > (omit_starts[idx] + omit_ends[idx]):
                df = df.iloc[omit_starts[idx] : len(df) - omit_ends[idx]].reset_index(drop=True)
            runs.append(df)

        # For each unique pair, compute the abs-error series and its own cumdist
        cumdists = []
        abs_errs = []
        for i, j in itertools.combinations(range(len(runs)), 2):
            df_i = runs[i]
            df_j = runs[j]

            # signed errors of run j vs run i
            dfj_err = compute_errors(df_i, df_j)
            errs = np.abs(dfj_err["PathError"].to_numpy())

            # cum‐dist for the *same* points as errs (dfj_err rows)
            coords_j = dfj_err[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
            segs_j = np.linalg.norm(np.diff(coords_j, axis=0), axis=1)
            cumdist_j = np.concatenate([[0], np.cumsum(segs_j)])

            cumdists.append(cumdist_j)
            abs_errs.append(errs)

        # # build a common grid 
        # max_lens = [cd[-1] for cd in cumdists]
        # common_max = min(max_lens)
        # grid = np.linspace(0, common_max, 1000)

        # # resample every error-curve onto that grid
        # err_stack = np.vstack([
        #     np.interp(grid, cumdists[k], abs_errs[k])
        #     for k in range(len(abs_errs))
        # ])

        # mean_err = err_stack.mean(axis=0)
        # max_err  = err_stack.max(axis=0)

        # # for plotting the path, pick run #1
        # ref = runs[0]
        # coords_ref   = ref[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
        # segs_ref     = np.linalg.norm(np.diff(coords_ref, axis=0), axis=1)
        # cumdist_ref  = np.concatenate([[0], np.cumsum(segs_ref)])
        # xs_ref       = -coords_ref[:,0]
        # ys_ref       = -coords_ref[:,1]

        # xs_grid = np.interp(grid, cumdist_ref, xs_ref)
        # ys_grid = np.interp(grid, cumdist_ref, ys_ref)

        # # plot mean‐error heatmap along the reference path
        # fig, ax = plt.subplots(figsize=(8,6))
        # sc = ax.scatter(xs_grid, ys_grid, c=mean_err, cmap="viridis", s=15)
        # cbar = fig.colorbar(sc, ax=ax)
        # cbar.set_label("GPS-Measured Mean Relative Lateral |Error| over all Repeats (m)")
        # ax.set_title(f"{group_name}: Mean Pairwise Error Along Route")
        # ax.axis("equal")
        # ax.grid(True, linestyle="--", linewidth=0.5)

        # # 7) print overall summary
        # print(f"\n{group_name} → mean of mean-errors = {mean_err.mean():.3f} m; global max-error = {max_err.max():.3f} m")

        # plt.show()

        # # ---- invoke for all groups ----
        # nominal_average_assessment(
        #     path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1,
        #     "Group 1 (Parking Loop)"
        # )
        # nominal_average_assessment(
        #     path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2,
        #     "Group 2 (Dome Loop)"
        # )
        # nominal_average_assessment(
        #     path_2_group3, path_2_omit_starts_group3, path_2_omit_ends_group3,
        #     "Group 3"
        # )
        # nominal_average_assessment(
        #     path_2_group4, path_2_omit_starts_group4, path_2_omit_ends_group4,
        #     "Group 4"
        # )

        # # Load & trim all runs for this group
        # trimmed_runs = []
        # for idx, p in enumerate(path_list):
        #     df = load_ecef_txt(p)
        #     if len(df) > (omit_starts[idx] + omit_ends[idx]):
        #         df = df.iloc[omit_starts[idx] : len(df) - omit_ends[idx]].reset_index(drop=True)
        #     trimmed_runs.append(df)

        # N = len(trimmed_runs)
        # rmse_mat = np.zeros((N, N))
        # max_mat = np.zeros((N, N))

        # # Compute pairwise RMSE and max error
        # for i, j in itertools.combinations(range(N), 2):
        #     df_i = trimmed_runs[i]
        #     df_j = trimmed_runs[j]
        #     dfj_err = compute_errors(df_i, df_j)
        #     errs = dfj_err["PathError"].to_numpy()
        #     rmse = np.sqrt(np.mean(errs**2))
        #     max_err = np.max(np.abs(errs))

        #     rmse_mat[i, j] = rmse_mat[j, i] = rmse
        #     max_mat[i, j] = max_mat[j, i] = max_err

        # Find the worst pairwise comparisons
        worst_rmse_pair = np.unravel_index(np.argmax(rmse_mat), rmse_mat.shape)
        worst_max_pair = np.unravel_index(np.argmax(max_mat), max_mat.shape)

        for pair, metric in [(worst_rmse_pair, "RMSE"), (worst_max_pair, "Max Error")]:
            i, j = pair
            df_i = trimmed_runs[i]
            df_j = trimmed_runs[j]

            # Compute errors of run j relative to run i
            dfj_err = compute_errors(df_i, df_j)
            errs = np.abs(dfj_err["PathError"].to_numpy())

            # Compute along-track distances
            coords_j = dfj_err[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
            segs_j = np.linalg.norm(np.diff(coords_j, axis=0), axis=1)
            cumdist_j = np.concatenate([[0], np.cumsum(segs_j)])

            # Build a common grid
            grid = np.linspace(0, cumdist_j[-1], 1000)

            # Resample errors onto the grid
            interp_errs = np.interp(grid, cumdist_j, errs)

            # For plotting the path, use run i as reference
            coords_ref = df_i[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
            segs_ref = np.linalg.norm(np.diff(coords_ref, axis=0), axis=1)
            cumdist_ref = np.concatenate([[0], np.cumsum(segs_ref)])
            xs_ref = -coords_ref[:, 0]
            ys_ref = -coords_ref[:, 1]

            xs_grid = np.interp(grid, cumdist_ref, xs_ref)
            ys_grid = np.interp(grid, cumdist_ref, ys_ref)

            # Plot heat map
            fig, ax = plt.subplots(figsize=(8, 6))
            sc = ax.scatter(xs_grid, ys_grid, c=interp_errs, cmap="viridis", s=15)
            cbar = fig.colorbar(sc, ax=ax)
            cbar.set_label(f"Lateral Path Tracking {metric} (m)")
            ax.set_title(f"{group_name}: Worst Pairwise Comparison by {metric} (Run {i+1} vs Run {j+1})")
            ax.axis("equal")
            ax.grid(True, linestyle="--", linewidth=0.5)
            #plt.show()

    fig, axs = plt.subplots(2, 2, figsize=(16, 12))
    axs = axs.flatten()

    # Collect all errors to determine global color scale
    all_interp_errs = []
    for group_name, path_list, omit_starts, omit_ends in [
        ("Group 1 (Parking Loop)", path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1),
        ("Group 2 (Dome Loop)", path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2),
        ("Group 3 (UTP2 Loop)", path_2_group3, path_2_omit_starts_group3, path_2_omit_ends_group3),
        ("Group 4 (UTP1 Loop)", path_2_group4, path_2_omit_starts_group4, path_2_omit_ends_group4),
    ]:
        df_i = load_ecef_txt(path_list[0]).iloc[omit_starts[0]:-omit_ends[0]].reset_index(drop=True)
        df_j = load_ecef_txt(path_list[1]).iloc[omit_starts[1]:-omit_ends[1]].reset_index(drop=True)
        dfj_err = compute_errors(df_i, df_j)
        errs = np.abs(dfj_err["PathError"].to_numpy())
        coords_j = dfj_err[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        segs_j = np.linalg.norm(np.diff(coords_j, axis=0), axis=1)
        cumdist_j = np.concatenate([[0], np.cumsum(segs_j)])
        grid = np.linspace(0, cumdist_j[-1], 1000)
        interp_errs = np.interp(grid, cumdist_j, errs)
        all_interp_errs.extend(interp_errs)

    # Determine global color scale
    vmin = min(all_interp_errs)
    vmax = max(all_interp_errs)

    # Adjust the layout to make room for the color bar
    #fig.subplots_adjust(right=0.8, wspace=0.3, hspace=0.3)

    # Adjust the layout to make the plots smaller and create more space for the color bar
    #fig.subplots_adjust(left=0.1, right=0.75, wspace=0.3, hspace=0.3)

    # Convert ECEF coordinates to a local ENU (East-North-Up) reference frame
    def ecef_to_enu(ecef_coords, ref_point):
        """
        Converts ECEF coordinates to ENU coordinates relative to a reference point.
        
        Parameters:
            ecef_coords (np.ndarray): Array of ECEF coordinates (N x 3).
            ref_point (np.ndarray): Reference point in ECEF coordinates (1 x 3).
        
        Returns:
            np.ndarray: ENU coordinates (N x 3).
        """
        ref_x, ref_y, ref_z = ref_point
        x, y, z = ecef_coords[:, 0] - ref_x, ecef_coords[:, 1] - ref_y, ecef_coords[:, 2] - ref_z

        # Compute the ENU transformation matrix
        phi = np.arctan2(ref_y, ref_x)  # Longitude
        theta = np.arctan2(ref_z, np.sqrt(ref_x**2 + ref_y**2))  # Latitude

        sin_phi, cos_phi = np.sin(phi), np.cos(phi)
        sin_theta, cos_theta = np.sin(theta), np.cos(theta)

        R = np.array([
            [-sin_phi, cos_phi, 0],
            [-cos_phi * sin_theta, -sin_phi * sin_theta, cos_theta],
            [cos_phi * cos_theta, sin_phi * cos_theta, sin_theta]
        ])

        enu_coords = np.dot(R, np.array([x, y, z]))
        return enu_coords.T

    # Reference point for ENU conversion (use the first point of the first path in each group)
    ref_point = load_ecef_txt(path_2_group1[0]).iloc[path_2_omit_starts_group1[0]].to_numpy()[1:4]

    # Plot each group with the same color scale in the ENU reference frame
    for idx, (group_name, path_list, omit_starts, omit_ends) in enumerate([
        ("Group 1 (Dome Loop)", path_2_group2, path_2_omit_starts_group2, path_2_omit_ends_group2),
        ("Group 2 (Parking Loop)", path_2_group1, path_2_omit_starts_group1, path_2_omit_ends_group1),
        ("Group 4 (UTP Parking Loop)", path_2_group4, path_2_omit_starts_group4, path_2_omit_ends_group4),
        ("Group 3 (UTP2 Survey)", path_2_group3, path_2_omit_starts_group3, path_2_omit_ends_group3),
    ]):
        df_i = load_ecef_txt(path_list[0]).iloc[omit_starts[0]:-omit_ends[0]].reset_index(drop=True)
        df_j = load_ecef_txt(path_list[1]).iloc[omit_starts[1]:-omit_ends[1]].reset_index(drop=True)
        dfj_err = compute_errors(df_i, df_j)
        errs = np.abs(dfj_err["PathError"].to_numpy())
        coords_j = dfj_err[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        segs_j = np.linalg.norm(np.diff(coords_j, axis=0), axis=1)
        cumdist_j = np.concatenate([[0], np.cumsum(segs_j)])
        grid = np.linspace(0, cumdist_j[-1], 1000)
        interp_errs = np.interp(grid, cumdist_j, errs)
        coords_ref = df_i[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        segs_ref = np.linalg.norm(np.diff(coords_ref, axis=0), axis=1)
        cumdist_ref = np.concatenate([[0], np.cumsum(segs_ref)])
        xs_ref = coords_ref[:, 0]
        ys_ref = coords_ref[:, 1]
        zs_ref = coords_ref[:, 2]
        xs_grid = np.interp(grid, cumdist_ref, xs_ref)
        ys_grid = np.interp(grid, cumdist_ref, ys_ref)
        zs_grid = np.interp(grid, cumdist_ref, zs_ref)

        # Convert to ENU
        enu_coords = ecef_to_enu(np.column_stack((xs_grid, ys_grid, zs_grid)), ref_point)
        xs_enu, ys_enu = enu_coords[:, 0], enu_coords[:, 1]

        # Flip over the vertical axis (negate x) and then the horizontal axis (negate y)
        xs_enu = -xs_enu
        ys_enu = -ys_enu

        ax = axs[idx]
        sc = ax.scatter(xs_enu, ys_enu, c=interp_errs, cmap="viridis", s=50, vmin=vmin, vmax=vmax)  
        ax.axis("equal")
        ax.grid(True, linestyle="--", linewidth=0.5)
        ax.set_xlabel("East (m)", fontsize=18)
        ax.set_ylabel("North (m)", fontsize=18)
        ax.tick_params(axis='both', which='major', labelsize=18)

    # Add a single color bar for the entire figure
    cbar_ax = fig.add_axes([0.88, 0.15, 0.02, 0.7])  # Moved further to the right
    cbar = fig.colorbar(sc, cax=cbar_ax)
    cbar.set_label("GPS-Measured Relative Lateral Path Tracking Error (m)", fontsize=18)
    cbar.ax.tick_params(labelsize=18)  # Adjust the font size of the color bar numbers

    plt.tight_layout(rect=[0, 0, 0.85, 1])  # Adjust layout to make space for colorbar
    plt.show()

'''
            
#     # — loop over every path_2 file, detect & confirm —
#     all_path2 = path_2_group1 + path_2_group2
#     all_starts = path_2_omit_starts_group1 + path_2_omit_starts_group2
#     all_ends   = path_2_omit_ends_group1   + path_2_omit_ends_group2

#     path2_markers = {}
#     for p, st, ed in zip(all_path2, all_starts, all_ends):
#         df = load_ecef_txt(p)
#         if len(df) > (st + ed):
#             df = df.iloc[st:len(df)-ed].reset_index(drop=True)
#         cand_idxs = detect_marker_candidates(df, heading_thresh=0.9)
#         print(f"\nFile: {os.path.basename(p)} → {len(cand_idxs)} candidates")
#         confirmed = confirm_markers(df, cand_idxs)
#         print(f"  confirmed {len(confirmed)} markers at indices {confirmed}")
#         # store actual ECEF-X,Y
#         path2_markers[p] = [
#             (float(df.loc[i,'ECEF-X']), float(df.loc[i,'ECEF-Y'])) for i in confirmed
#         ]

#     # save to disk for later use
#     out_fn = "/home/desiree/ASRL/vtr3/path2_confirmed_markers.json"
#     with open(out_fn, 'w') as jf:
#         json.dump(path2_markers, jf, indent=2)
#     print(f"\nSaved confirmed path_2 markers to {out_fn}")

#  # for Parking:
#     parking_raw_file = '/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parkingteach/parkingteachppkECEF.txt'
#     parking_start_time = '1740173617.275629238'
#     parking_marker_times = [
#         #'1740173618.528000000', #spray painted both here - cutoff by trimming
#         '1740173644.145631574',  #spray painted both here
#         '1740173734.635998493',  
#         '1740173793.985451428',
#         '1740173869.681489399',
#         '1740173952.872956555',
#         '1740174028.452038838',
#         '1740174096.330397755',
#         '1740174170.565191862',
#         '1740174228.910205260',
#         '1740173644.145631574'
#         #'1740173618.528000000' # cutoff by trimming
#     ]
#     parking_gt_xy = get_marker_xy_from_times(
#         parking_raw_file,
#         path_2[0],
#         parking_start_time,
#         parking_marker_times
#     )

#     # for Mars:
#     mars_raw_file = '/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dometeach/dometeachppkECEF.txt'
#     mars_start_time = '1740537808.367129590'
#     mars_marker_times = [
#         '1740537856.732332585',
#         '1740537915.208267997',
#         '1740538027.798453285',
#         '1740538066.247964487',
#         '1740538092.071590682',
#         '1740538121.832458139',
#         '1740538154.489547849', 
#         '1740538186.941014071'
#     ]
#     mars_gt_xy = get_marker_xy_from_times(
#         mars_raw_file,
#         path_2[6],
#         mars_start_time,
#         mars_marker_times
#     )

#     for (group_name,
#          teach_paths, teach_starts, teach_ends,
#          repeat_aligned_dfs, marker_xy) in [
#         ("Parking Loop",
#          path_1_group1, path_1_omit_starts_group1, path_1_omit_ends_group1,
#          aligned_group1_path1, parking_gt_xy),
#         ("Dome Loop",
#          path_1_group2, path_1_omit_starts_group2, path_1_omit_ends_group2,
#          aligned_group2_path1, mars_gt_xy),
#     ]:
#         print(f"\n=== {group_name} ===")

#         # Teach runs
#         print(" Teach runs:")
#         for run_idx, (p, st, ed) in enumerate(
#             zip(teach_paths, teach_starts, teach_ends), start=1):
#             df_run = load_ecef_txt(p)
#             if len(df_run) > (st + ed):
#                 df_run = df_run.iloc[st: len(df_run)-ed].reset_index(drop=True)
#             idxs, poses, dists = find_marker_positions(df_run, marker_xy)
#             for m, (i, (px, py), d) in enumerate(zip(idxs, poses, dists), start=1):
#                 print(f"  Teach Run {run_idx}, Marker {m}: idx={i}, pos=({px:.3f},{py:.3f}), dist={d:.3f} m")

#             # Plot the teach path with markers overlaid
#             x = -df_run['ECEF-X'].to_numpy()
#             y = -df_run['ECEF-Y'].to_numpy()
#             marker_x = [-px for px, _ in poses]
#             marker_y = [-py for _, py in poses]

#             plt.figure(figsize=(8, 6))
#             plt.plot(x, y, '-', label=f"Teach Run {run_idx}", linewidth=2)
#             plt.scatter(marker_x, marker_y, c='red', s=50, label='Markers')
#             plt.xlabel("ECEF-X (m)", fontsize=14)
#             plt.ylabel("ECEF-Y (m)", fontsize=14)
#             plt.title(f"Teach Run {run_idx} with Markers", fontsize=16)
#             plt.legend(fontsize=12)
#             plt.axis("equal")
#             plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
#             plt.show()

        # # Repeat runs (ICP‑aligned)
        # print(" Repeat runs (ICP‑aligned):")
        # for run_idx, df_al in enumerate(repeat_aligned_dfs, start=1):
        #     idxs, poses, dists = find_marker_positions(df_al, marker_xy)
        #     for m, (i, (px, py), d) in enumerate(zip(idxs, poses, dists), start=1):
        #         print(f"  Repeat Run {run_idx}, Marker {m}: idx={i}, pos=({px:.3f},{py:.3f}), dist={d:.3f} m")

        #     # Plot the repeat path with markers overlaid
        #     x = -df_al['ECEF-X'].to_numpy()
        #     y = -df_al['ECEF-Y'].to_numpy()
        #     marker_x = [-px for px, _ in poses]
        #     marker_y = [-py for _, py in poses]

        #     plt.figure(figsize=(8, 6))
        #     plt.plot(x, y, '--', label=f"Repeat Run {run_idx}", linewidth=2)
        #     plt.scatter(marker_x, marker_y, c='red', s=50, label='Markers')
        #     plt.xlabel("ECEF-X (m)", fontsize=14)
        #     plt.ylabel("ECEF-Y (m)", fontsize=14)
        #     plt.title(f"Repeat Run {run_idx} with Markers", fontsize=16)
        #     plt.legend(fontsize=12)
        #     plt.axis("equal")
        #     plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
        #     plt.show()

            # # Perform ICP alignment using the markers for each path comparison
            # def icp_with_markers(source_markers, target_markers):
            #     """
            #     Perform ICP alignment using markers.
                
            #     Parameters:
            #         source_markers (list[tuple[float, float]]): List of (x, y) markers for the source.
            #         target_markers (list[tuple[float, float]]): List of (x, y) markers for the target.
                
            #     Returns:
            #         np.ndarray: Rotation matrix (2x2).
            #         np.ndarray: Translation vector (2x1).
            #     """
            #     source_points = np.array(source_markers)
            #     target_points = np.array(target_markers)

            #     # Compute centroids
            #     centroid_source = np.mean(source_points, axis=0)
            #     centroid_target = np.mean(target_points, axis=0)

            #     # Center the points
            #     source_centered = source_points - centroid_source
            #     target_centered = target_points - centroid_target

            #     # Compute the optimal rotation using Singular Value Decomposition (SVD)
            #     H = source_centered.T @ target_centered
            #     U, _, Vt = np.linalg.svd(H)
            #     R = Vt.T @ U.T

            #     # Ensure a proper rotation (det(R) = 1)
            #     if np.linalg.det(R) < 0:
            #         Vt[-1, :] *= -1
            #         R = Vt.T @ U.T

            #     # Compute the translation vector
            #     t = centroid_target - R @ centroid_source

            #     return R, t

            # # Apply the ICP transformation to the entire trajectory
            # def apply_icp_transformation(df, R, t):
            #     """
            #     Apply the ICP transformation to the entire trajectory.
                
            #     Parameters:
            #         df (pd.DataFrame): DataFrame with 'ECEF-X', 'ECEF-Y', 'ECEF-Z'.
            #         R (np.ndarray): Rotation matrix (2x2).
            #         t (np.ndarray): Translation vector (2x1).
                
            #     Returns:
            #         pd.DataFrame: Transformed DataFrame.
            #     """
            #     points = df[['ECEF-X', 'ECEF-Y']].to_numpy()
            #     transformed_points = (R @ points.T).T + t
            #     transformed_df = df.copy()
            #     transformed_df[['ECEF-X', 'ECEF-Y']] = transformed_points
            #     return transformed_df

            # # Perform ICP alignment for each path comparison and apply the transformation
            # final_aligned_paths_group1 = []
            # for idx, (teach_path, repeat_path) in enumerate(zip(path_1_group1, path_2_group1)):
            #     teach_markers = parking_gt_xy
            #     repeat_markers = path2_markers[repeat_path]
            #     R, t = icp_with_markers(teach_markers, repeat_markers)

            #     # Load and trim the teach path
            #     teach_df = load_ecef_txt(teach_path).iloc[path_1_omit_starts_group1[idx]:-path_1_omit_ends_group1[idx]].reset_index(drop=True)
            #     aligned_teach_df = apply_icp_transformation(teach_df, R, t)
            #     final_aligned_paths_group1.append(aligned_teach_df)

            # final_aligned_paths_group2 = []
            # for idx, (teach_path, repeat_path) in enumerate(zip(path_1_group2, path_2_group2)):
            #     teach_markers = mars_gt_xy
            #     repeat_markers = path2_markers[repeat_path]
            #     R, t = icp_with_markers(teach_markers, repeat_markers)

            #     # Load and trim the teach path
            #     teach_df = load_ecef_txt(teach_path).iloc[path_1_omit_starts_group2[idx]:-path_1_omit_ends_group2[idx]].reset_index(drop=True)
            #     aligned_teach_df = apply_icp_transformation(teach_df, R, t)
            #     final_aligned_paths_group2.append(aligned_teach_df)

            # # Plot the final aligned trajectories for group 1 and group 2
            # plot_overlaid_df_trajectories(final_aligned_paths_group1, 
            #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group1[idx]:-path_2_omit_ends_group1[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group1)], 
            #                               suptitle="Final Marker-Based ICP Alignment for Group 1 (Parking Loop)")

            # plot_overlaid_df_trajectories(final_aligned_paths_group2, 
            #                               [load_ecef_txt(p).iloc[path_2_omit_starts_group2[idx]:-path_2_omit_ends_group2[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group2)], 
            #                               suptitle="Final Marker-Based ICP Alignment for Group 2 (Dome Loop)")
            '''
if __name__ == "__main__":
    main()
