import os
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
import vtr_regression_testing.path_comparison as vtr_path

def align_path(file_path1, file_path2, omit_start1=0, omit_end1=0, omit_start2=0, omit_end2=0):
    """
    Aligns the ECEF data from file_path1 to the frame of file_path2 using trimmed data.
    
    The function:
      1. Loads the ECEF data for each file using load_ecef_txt.
      2. Trims the data based on the provided omit_start and omit_end values.
      3. Extracts the first valid measurement (first row's 'ECEF-X', 'ECEF-Y', 'ECEF-Z')
         from each trimmed dataset.
      4. Computes the translation vector as:
             translation_vector = first_point_file2 - first_point_file1
      5. Applies this translation to all rows of the trimmed data from file_path1.
      6. Returns the translated (aligned) DataFrame.
    
    Parameters
        file_path1 (str): The file path for the dataset to be shifted.
        file_path2 (str): The file path for the reference dataset.
        omit_start1 (int): Number of rows to omit from the beginning of file_path1.
        omit_end1 (int): Number of rows to omit from the end of file_path1.
        omit_start2 (int): Number of rows to omit from the beginning of file_path2.
        omit_end2 (int): Number of rows to omit from the end of file_path2.
    
    Returns:
        pd.DataFrame: A DataFrame with the aligned (trimmed and shifted) ECEF data from file_path1.
    """
    # Load data from both files.
    df1 = load_ecef_txt(file_path1)
    df2 = load_ecef_txt(file_path2)
    
    # Apply trimming to df1 if necessary.
    if len(df1) > (omit_start1 + omit_end1):
        df1 = df1.iloc[omit_start1: len(df1) - omit_end1].reset_index(drop=True)
    
    # Apply trimming to df2 if necessary.
    if len(df2) > (omit_start2 + omit_end2):
        df2 = df2.iloc[omit_start2: len(df2) - omit_end2].reset_index(drop=True)
    
    # Extract the first valid ECEF measurement from each trimmed dataset.
    ref1 = df1[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].iloc[0].to_numpy()
    ref2 = df2[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].iloc[0].to_numpy()
    
    # Compute the translation vector.
    translation_vector = ref2 - ref1
    print("Reference point from file 1 (trimmed):", ref1)
    print("Reference point from file 2 (trimmed):", ref2)
    print("Computed translation vector to align file 1 to file 2:", translation_vector)
    
    # Apply the translation vector to all rows in df1.
    df1_aligned = df1.copy()
    df1_aligned[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = df1_aligned[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] + translation_vector
    
    return df1_aligned

def load_ecef_txt(path):
    # Read the file, skipping the first 16 rows, and assign column names manually.
    df = pd.read_csv(path, sep='\s+', header=None, skiprows=16, names=['ID', 'ECEF-X', 'ECEF-Y', 'ECEF-Z'])
    df = df.dropna()
    df['ID'] = pd.to_numeric(df['ID'], errors='coerce')
    df = df.dropna(subset=['ID']).reset_index(drop=True)
    df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].astype(float)
    return df

def path_to_matrix(gps_data):
    points = []
    for idx in range(1, len(gps_data)):
        x0 = gps_data.iloc[idx - 1].to_numpy()
        x1 = gps_data.iloc[idx].to_numpy()
        l = np.linalg.norm(x1 - x0)
        if l < 1e-6:
            continue
        n = (x1 - x0) / l
        row = np.concatenate([x0, n, [l]])
        points.append(row)
    if points:
        last_row = points[-1]
        final_row = np.concatenate([last_row[:3], -last_row[3:6], [last_row[6]]])
        points.append(final_row)
    return np.vstack(points) if points else np.empty((0, 7))

def compute_errors(teach_df, repeat_df):
    # Compute the teach path matrix from the teach trajectory (using ECEF-X, Y, Z)
    teach_matrix = path_to_matrix(teach_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']])
    # Compute the signed lateral error for each point in the repeat trajectory relative to the teach path.
    errors = repeat_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].apply(
        lambda row: vtr_path.signed_distance_to_path(row.to_numpy(), teach_matrix), axis=1)
    repeat_df["PathError"] = errors
    return repeat_df

def plot_path(path_1, path_2,
                path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends,
                suptitle,
                colorbar_title):
    if not (len(path_1) == len(path_2) == len(path_1_omit_starts) ==
            len(path_1_omit_ends) == len(path_2_omit_starts) == len(path_2_omit_ends)):
        raise ValueError("All input lists must have the same length.")

    num_pairs = len(path_1)
    # For teach vs repeat group, if there are exactly two comparisons arrange them side-by-side.
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()

    all_abs_errors = []
    pairs_data = []  # Store tuples of (path_1_df, path_2_df) after trimming

    for idx, (p1, p2, p1_omit_start, p1_omit_end, p2_omit_start, p2_omit_end) in enumerate(
            zip(path_1, path_2, path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends)):
        p1_df = load_ecef_txt(p1)
        p2_df = load_ecef_txt(p2)

        # Omit specified measurements from path_1 and path_2 separately.
        if len(p1_df) > (p1_omit_start + p1_omit_end):
            p1_df = p1_df.iloc[p1_omit_start: len(p1_df) - p1_omit_end].reset_index(drop=True)
        if len(p2_df) > (p2_omit_start + p2_omit_end):
            p2_df = p2_df.iloc[p2_omit_start: len(p2_df) - p2_omit_end].reset_index(drop=True)

        # Compute errors for path_2 relative to path_1.
        p2_df = compute_errors(p1_df, p2_df)
        pairs_data.append((p1_df, p2_df))
        all_abs_errors.extend(p2_df["PathError"].abs().tolist())

        # Calculate RMSE and maximum lateral error for this pair.
        errors = p2_df["PathError"].to_numpy()
        rmse = np.sqrt(np.mean(errors**2))
        max_error = np.max(np.abs(errors))
        print(f"Path Pair {idx+1}: RMSE = {rmse:.3f} m, Max Lateral Error = {max_error:.3f} m")

    # Determine global color scale for absolute error.
    vmin = 0
    vmax = max(all_abs_errors) if all_abs_errors else 1

    # Plot each pair in its own subplot.
    for idx, (p1_df, p2_df) in enumerate(pairs_data):
        ax = axs[idx]
        # For the error plot, we rotate the p2 trajectory:
        x = -p2_df['ECEF-X'].to_numpy()  
        y = -p2_df['ECEF-Y'].to_numpy()
        abs_errors = p2_df['PathError'].abs().to_numpy()

        sc = ax.scatter(x, y, c=abs_errors, cmap='viridis', vmin=vmin, vmax=vmax, marker='o')
        ax.set_xlabel('ECEF-X (m)', fontsize=14)
        ax.set_ylabel('ECEF-Y (m)', fontsize=14)
        ax.set_title(f'', fontsize=16)
        ax.axis('equal')
        ax.grid(True, which='both', color='lightgrey', linestyle='-', linewidth=0.5, zorder=-1)
        ax.tick_params(axis='both', which='major', labelsize=12)

    # Remove any unused subplots.
    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])

    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.87, 0.15, 0.02, 0.7])
    cbar = fig.colorbar(sc, cax=cbar_ax)
    cbar.set_label(colorbar_title, fontsize=14)

    plt.suptitle(suptitle, fontsize=20)
    plt.show()

def plot_overlaid_trajectories(path_1, path_2,
                               path_1_omit_starts, path_1_omit_ends,
                               path_2_omit_starts, path_2_omit_ends,
                               suptitle="Overlaid Teach (Solid Blue) and Repeat (Dashed Red) Trajectories"):
    if not (len(path_1) == len(path_2) == len(path_1_omit_starts) ==
            len(path_1_omit_ends) == len(path_2_omit_starts) == len(path_2_omit_ends)):
        raise ValueError("All input lists must have the same length.")

    num_pairs = len(path_1)
    # For teach vs repeat group with two comparisons, force side-by-side: 1 row × 2 columns.
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()

    for idx, (p1, p2, p1_omit_start, p1_omit_end, p2_omit_start, p2_omit_end) in enumerate(
            zip(path_1, path_2, path_1_omit_starts, path_1_omit_ends,
                path_2_omit_starts, path_2_omit_ends)):
        p1_df = load_ecef_txt(p1)
        p2_df = load_ecef_txt(p2)

        # Omit specified measurements from each trajectory.
        if len(p1_df) > (p1_omit_start + p1_omit_end):
            p1_df = p1_df.iloc[p1_omit_start: len(p1_df) - p1_omit_end].reset_index(drop=True)
        if len(p2_df) > (p2_omit_start + p2_omit_end):
            p2_df = p2_df.iloc[p2_omit_start: len(p2_df) - p2_omit_end].reset_index(drop=True)

        ax = axs[idx]
        # Rotate both trajectories by multiplying by -1.
        p1_x = -p1_df['ECEF-X'].to_numpy()
        p1_y = -p1_df['ECEF-Y'].to_numpy()
        p2_x = -p2_df['ECEF-X'].to_numpy()
        p2_y = -p2_df['ECEF-Y'].to_numpy()

        # Plot the first trajectory (e.g. Teach) as a solid blue line.
        ax.plot(p1_x, p1_y, '-', color='blue', markersize=3, linewidth=2, label="Teach Trajectory")
        # Plot the second trajectory (e.g. Repeat) as a dashed red line.
        ax.plot(p2_x, p2_y, '--', color='red', markersize=3, linewidth=2, label="Repeat Trajectory")
        ax.set_xlabel('ECEF-X (m)', fontsize=14)
        ax.set_ylabel('ECEF-Y (m)', fontsize=14)
        ax.set_title(f'', fontsize=16)
        ax.axis('equal')
        ax.grid(True, which='both', color='lightgrey', linestyle='-', linewidth=0.5, zorder=-1)
        ax.tick_params(axis='both', which='major', labelsize=12)
        ax.legend(fontsize=12)

    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])

    plt.suptitle(suptitle, fontsize=20)
    plt.show()

def plot_overlaid_df_trajectories(df_list1, df_list2, suptitle="Overlaid Trajectories"):
    """
    Plots overlaid trajectories given as two lists of DataFrames.
    
    For each pair (df1, df2) in the input lists, df1 is plotted as a solid blue line
    (e.g. the aligned trajectory) and df2 is plotted as a dashed red line (e.g. the reference).
    It assumes each DataFrame has columns 'ECEF-X', 'ECEF-Y', and 'ECEF-Z'.
    """
    import matplotlib.pyplot as plt
    num_pairs = len(df_list1)
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()
    
    for idx, (df1, df2) in enumerate(zip(df_list1, df_list2)):
        ax = axs[idx]
        # Multiply by -1 to match the rotation used elsewhere.
        x1 = -df1['ECEF-X'].to_numpy()
        y1 = -df1['ECEF-Y'].to_numpy()
        x2 = -df2['ECEF-X'].to_numpy()
        y2 = -df2['ECEF-Y'].to_numpy()
        ax.plot(x1, y1, '-', color='blue', markersize=3, linewidth=2, label="Reference Trajectory")
        ax.plot(x2, y2, '--', color='red', markersize=3, linewidth=2, label="Aligned Trajectory")
        ax.set_xlabel("ECEF-X (m)", fontsize=14)
        ax.set_ylabel("ECEF-Y (m)", fontsize=14)
        ax.set_title(f"Trajectory Pair {idx+1}", fontsize=16)
        ax.axis("equal")
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
        ax.legend(fontsize=12)
    for j in range(idx + 1, len(axs)):
        fig.delaxes(axs[j])
    plt.suptitle(suptitle, fontsize=20)
    plt.show()
    
def plot_path_df(df_list1, df_list2, suptitle="", colorbar_title=""):
    """
    Computes and plots the signed lateral error for each pair of trajectories in df_list1 (teach) vs df_list2 (repeat).
    It uses your existing compute_errors function on the DataFrame pairs.
    Note: This version rotates the plot by 180 degrees by using the original ECEF coordinates.
    The plotted coordinates are made relative by subtracting the first point of each trajectory.
    """
    num_pairs = len(df_list1)
    if num_pairs == 2:
        nrows, ncols = 1, 2
    else:
        nrows = int(np.ceil(np.sqrt(num_pairs)))
        ncols = int(np.ceil(num_pairs / nrows))
        
    fig, axs = plt.subplots(nrows, ncols, figsize=(10 * ncols, 8 * nrows))
    axs = np.atleast_1d(axs).flatten()
    
    all_abs_errors = []
    pairs_data = []
    for idx, (df1, df2) in enumerate(zip(df_list1, df_list2)):
        df2_err = compute_errors(df1, df2)
        pairs_data.append((df1, df2_err))
        all_abs_errors.extend(df2_err["PathError"].abs().tolist())
    vmin = 0
    vmax = max(all_abs_errors) if all_abs_errors else 1
    
    for idx, (df1, df2_err) in enumerate(pairs_data):
        ax = axs[idx]
        # Original ECEF coordinates from df2_err.
        x = df2_err['ECEF-X'].to_numpy()
        y = df2_err['ECEF-Y'].to_numpy()
        # Convert to relative coordinates by subtracting the first value.
        x_rel = x - x[0]
        y_rel = y - y[0]
        abs_errors = df2_err['PathError'].abs().to_numpy()
        sc = ax.scatter(x_rel, y_rel, c=abs_errors, cmap='viridis', vmin=vmin, vmax=vmax, marker='o')
        ax.set_xlabel("East (m)", fontsize=14)
        ax.set_ylabel("North (m)", fontsize=14)
        #ax.set_title(f"Error Plot Pair {idx+1}", fontsize=16)
        ax.axis("equal")
        ax.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
    for j in range(idx+1, len(axs)):
        fig.delaxes(axs[j])
    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.87, 0.15, 0.02, 0.7])
    cbar = fig.colorbar(sc, cax=cbar_ax)
    cbar.set_label(colorbar_title, fontsize=14)
    plt.suptitle(suptitle, fontsize=20)

def icp_align(source_df, target_df, max_iterations=50, tolerance=1e-6):
        """
        Perform Iterative Closest Point (ICP) to align source_df to target_df.
        
        Parameters:
            source_df (pd.DataFrame): Source trajectory DataFrame with 'ECEF-X', 'ECEF-Y', 'ECEF-Z'.
            target_df (pd.DataFrame): Target trajectory DataFrame with 'ECEF-X', 'ECEF-Y', 'ECEF-Z'.
            max_iterations (int): Maximum number of ICP iterations.
            tolerance (float): Convergence tolerance for the transformation.
        
        Returns:
            pd.DataFrame: Aligned source DataFrame.
        """
        source_points = source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        target_points = target_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].to_numpy()
        
        prev_error = float('inf')
        for i in range(max_iterations):
            # Find the nearest neighbors in the target for each point in the source.
            nbrs = NearestNeighbors(n_neighbors=1).fit(target_points)
            distances, indices = nbrs.kneighbors(source_points)
            closest_points = target_points[indices.flatten()]
            
            # Compute the centroids of the source and target points.
            centroid_source = np.mean(source_points, axis=0)
            centroid_target = np.mean(closest_points, axis=0)
            
            # Center the points around their centroids.
            source_centered = source_points - centroid_source
            target_centered = closest_points - centroid_target
            
            # Compute the optimal rotation using Singular Value Decomposition (SVD).
            H = source_centered.T @ target_centered
            U, _, Vt = np.linalg.svd(H)
            R = Vt.T @ U.T
            
            # Ensure a proper rotation (det(R) = 1).
            if np.linalg.det(R) < 0:
                Vt[-1, :] *= -1
                R = Vt.T @ U.T
            
            # Compute the translation vector.
            t = centroid_target - R @ centroid_source
            
            # Apply the transformation to the source points.
            source_points = (R @ source_points.T).T + t
            
            # Check for convergence.
            mean_error = np.mean(distances)
            if abs(prev_error - mean_error) < tolerance:
                break
            prev_error = mean_error
        
        # Create a new DataFrame for the aligned source points.
        aligned_source_df = source_df.copy()
        aligned_source_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']] = source_points
        return aligned_source_df

def main():
    # Full lists of file paths for teach and repeat trajectories.
    path_1 = [
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_44_53.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_34_37.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-14_16_13.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2ppkECEF_novatel_data_2025_02_25-04_36_36.txt",
        
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dometeach/dometeachppkECEF.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parkingteach/parkingteachppkECEF.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dometeach/dometeachppkECEF.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parkingteach/parkingteachppkECEF.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_mesh_path_ecef.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt"

    ]
    path_2 = [
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp1cars/utp1ppkECEF_novatel_data_2025_02_24-14_26_12.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/utp2nocars/utp2ppkECEF_novatel_data_2025_02_25-04_46_49.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_38_21.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_34_37.txt",

        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt"
    ]

    '''
    # For /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt and /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_38_21.txt
    # path_1_omit_starts = [190, 850, 380, 145, 20, 5, 20, 5]
    # path_1_omit_ends   = [100, 790, 400, 378, 40, 70, 40, 70]
    # # And specify omission for the second dataset.
    # path_2_omit_starts = [155, 715, 307, 223, 185, 720, 155, 715]
    # path_2_omit_ends   = [52, 798, 423, 320, 97, 790, 52, 798]

    # For /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_44_53.txt and /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_38_21.txt
    # path_1_omit_starts = [190, 850, 380, 145, 20, 5, 20, 5]
    # path_1_omit_ends   = [100, 790, 400, 378, 40, 70, 40, 70]
    # # And specify omission for the second dataset.
    # path_2_omit_starts = [165, 715, 307, 223, 185, 720, 155, 715]
    # path_2_omit_ends   = [52, 798, 423, 320, 97, 790, 52, 798]
    '''

    # For /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_44_53.txt and /home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt
    path_1_omit_starts = [190, 850, 380, 145, 20, 5, 20, 5, 57, 50]
    path_1_omit_ends   = [100, 790, 400, 378, 40, 70, 40, 70, 104, 50]
    # And specify omission for the second dataset.
    path_2_omit_starts = [195, 715, 307, 223, 185, 720, 155, 715, 155, 715]
    path_2_omit_ends   = [52, 798, 423, 320, 97, 790, 52, 798, 52, 798]

    # Path beginning and ending omissions for ICP aligned paths (teach path)
    aligned_dome_omit_start = 58   
    aligned_dome_omit_end   = 105 
    aligned_parking_omit_start = 45 
    aligned_parking_omit_end   = 50 

    # Split data into three groups:
    # First four comparisons represent the first group.
    path_1_group1 = path_1[:4]
    path_2_group1 = path_2[:4]
    path_1_omit_starts_group1 = path_1_omit_starts[:4]
    path_1_omit_ends_group1 = path_1_omit_ends[:4]
    path_2_omit_starts_group1 = path_2_omit_starts[:4]
    path_2_omit_ends_group1 = path_2_omit_ends[:4]

    # The next four comparisons represent the second group.
    path_1_group2 = path_1[4:8]
    path_2_group2 = path_2[4:8]
    path_1_omit_starts_group2 = path_1_omit_starts[4:8]
    path_1_omit_ends_group2 = path_1_omit_ends[4:8]
    path_2_omit_starts_group2 = path_2_omit_starts[4:8]
    path_2_omit_ends_group2 = path_2_omit_ends[4:8]

    # The last two comparisons represent the third group.
    path_1_group3 = path_1[-2:]
    path_2_group3 = path_2[-2:]
    path_1_omit_starts_group3 = path_1_omit_starts[-2:]
    path_1_omit_ends_group3 = path_1_omit_ends[-2:]
    path_2_omit_starts_group3 = path_2_omit_starts[-2:]
    path_2_omit_ends_group3 = path_2_omit_ends[-2:]

    # Plot overlaid trajectories for group 1 (repeat vs repeat).
    #plot_overlaid_trajectories(path_1_group1, path_2_group1, path_1_omit_starts_group1, path_1_omit_ends_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, suptitle="Overlaid Repeat vs Repeat Trajectories (Group 1)")
   
    # Plot overlaid trajectories for group 2 (teach vs repeat).
    #plot_overlaid_trajectories(path_1_group2, path_2_group2, path_1_omit_starts_group2, path_1_omit_ends_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, suptitle="Overlaid Teach vs Repeat Trajectories (Group 2)")
    
    # Plot overlaid trajectories for group 3 (pseudo-gazebo-GPS vs real repeat).
    plot_overlaid_trajectories(path_1_group3, path_2_group3, path_1_omit_starts_group3, path_1_omit_ends_group3, path_2_omit_starts_group3, path_2_omit_ends_group3, suptitle="Overlaid Pseudo-Gazebo-GPS vs Real Repeat Trajectories (Group 3)")

    # --- Create Group 4 by aligning group 3 teach and repeat according to difference between their first poses for dome and parking (use the trimming values from group 3) ---
    aligned_path_dome = align_path(path_1[8], path_2[8],
                                   omit_start1=aligned_dome_omit_start,
                                   omit_end1=aligned_dome_omit_end,
                                   omit_start2=path_2_omit_starts_group3[0],
                                   omit_end2=path_2_omit_ends_group3[0])
    aligned_path_parking = align_path(path_1[9], path_2[9],
                                      omit_start1=aligned_parking_omit_start,
                                      omit_end1=aligned_parking_omit_end,
                                      omit_start2=path_2_omit_starts_group3[1],
                                      omit_end2=path_2_omit_ends_group3[1])
    
    # Make DataFrames for the reference datasets in group 4 (the repeat GPS), load and trim the corresponding path_2 files as done above.
    df_path2_dome = load_ecef_txt(path_2[8])
    if len(df_path2_dome) > (path_2_omit_starts_group3[0] + path_2_omit_ends_group3[0]):
        df_path2_dome = df_path2_dome.iloc[path_2_omit_starts_group3[0]:len(df_path2_dome)-path_2_omit_ends_group3[0]].reset_index(drop=True)
    
    df_path2_parking = load_ecef_txt(path_2[9])
    if len(df_path2_parking) > (path_2_omit_starts_group3[1] + path_2_omit_ends_group3[1]):
        df_path2_parking = df_path2_parking.iloc[path_2_omit_starts_group3[1]:len(df_path2_parking)-path_2_omit_ends_group3[1]].reset_index(drop=True)
    
    # Form group 4 lists from the DataFrames.
    group4_path1 = [aligned_path_dome, aligned_path_parking]
    group4_path2 = [df_path2_dome, df_path2_parking]
    
    # Plot the overlaid trajectories for group 4.
    #plot_overlaid_df_trajectories(group4_path1, group4_path2, suptitle="Group 4: Overlaid Manually Aligned vs Reference Trajectories")
    
    # Perform ICP alignment for group 3 trajectories.
    aligned_group3_path1 = []
    for idx, (df1, df2) in enumerate(zip(path_1_group3, path_2_group3)):
        df1_trimmed = load_ecef_txt(df1).iloc[path_1_omit_starts_group3[idx]:-path_1_omit_ends_group3[idx]].reset_index(drop=True)
        df2_trimmed = load_ecef_txt(df2).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True)
        aligned_df1 = icp_align(df1_trimmed, df2_trimmed)
        aligned_group3_path1.append(aligned_df1)

    # Plot the ICP-aligned trajectories for group 3.
    plot_overlaid_df_trajectories(aligned_group3_path1, [load_ecef_txt(p).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group3)], suptitle="Group 5: ICP-Aligned vs Reference Trajectories")

    # Plot error (signed-distance) plots for group 1 (repeat vs repeat).
    #plot_path(path_1_group1, path_2_group1, path_1_omit_starts_group1, path_1_omit_ends_group1, path_2_omit_starts_group1, path_2_omit_ends_group1, suptitle="Repeat vs Repeat Error (Group 1)", colorbar_title="GPS Measured Lateral Error Between Repeats (m)")
    
    # Plot error (signed-distance) plots for group 2 (teach vs repeat).
    #plot_path(path_1_group2, path_2_group2, path_1_omit_starts_group2, path_1_omit_ends_group2, path_2_omit_starts_group2, path_2_omit_ends_group2, suptitle="Teach vs Repeat Error (Group 2)", colorbar_title="GPS Measured Lateral Error Between Real World Teach and Virtual Repeat (m)")
    
    # Plot error (signed-distance) plots for group 3 (pseudo-gazebo-GPS vs real repeat).
    #plot_path(path_1_group3, path_2_group3, path_1_omit_starts_group3, path_1_omit_ends_group3, path_2_omit_starts_group3, path_2_omit_ends_group3, suptitle="Pseudo-Gazebo-GPS vs Real Repeat Error (Group 3)", colorbar_title="GPS Measured Lateral Error Between Pseudo-Gazebo-GPS and Real Repeat (m)")                   

    # Plot error (signed-distance) plots for group 4 (manually aligned pseudo-gazebo-GPS vs real repeat).
    #plot_path_df(group4_path1, group4_path2, suptitle="Trimmed Pseudo-Gazebo-GPS vs Real Repeat Error (Group 4)", colorbar_title="GPS Measured Lateral Error Between Pseudo-Gazebo-GPS and Real Repeat (m)")
                
    # Plot the signed lateral error (signed-distance) plots for ICP-aligned trajectories in group 3.
    plot_path_df(aligned_group3_path1, [load_ecef_txt(p).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True) for idx, p in enumerate(path_2_group3)], suptitle="", colorbar_title="")

    # Compute RMSE and maximum lateral error for group 4.
    #for idx, (aligned_df, reference_df) in enumerate(zip(group4_path1, group4_path2)):
    #    reference_df = compute_errors(aligned_df, reference_df)
    #    errors = reference_df["PathError"].to_numpy()
    #    rmse = np.sqrt(np.mean(errors**2))
    #    max_error = np.max(np.abs(errors))
    #    print(f"Group 4 - Path Pair {idx+1}: RMSE = {rmse:.3f} m, Max Lateral Error = {max_error:.3f} m")

    # Compute RMSE and maximum lateral error for the aligned trajectories.
    for idx, (aligned_df, reference_path) in enumerate(zip(aligned_group3_path1, path_2_group3)):
        reference_df = load_ecef_txt(reference_path).iloc[path_2_omit_starts_group3[idx]:-path_2_omit_ends_group3[idx]].reset_index(drop=True)
        reference_df = compute_errors(aligned_df, reference_df)
        errors = reference_df["PathError"].to_numpy()
        rmse = np.sqrt(np.mean(errors**2))
        max_error = np.max(np.abs(errors))
        print(f"Group 5 (ICP Aligned) - Path Pair {idx+1}: RMSE = {rmse:.3f} m, Max Lateral Error = {max_error:.3f} m")

        # Plot the lateral path tracking error for the aligned paths.
        plt.figure(figsize=(10, 6))
        plt.plot(reference_df.index.to_numpy(), reference_df["PathError"].to_numpy(), label="Lateral Error", color="blue", linewidth=2)
        plt.axhline(0, color="black", linestyle="--", linewidth=1)
        plt.xlabel("Index", fontsize=14)
        plt.ylabel("Lateral Error (m)", fontsize=14)
        plt.title(f"Group 5 - Path Pair {idx+1}: Lateral Error", fontsize=16)
        plt.legend(fontsize=12)
        plt.grid(True, which="both", color="lightgrey", linestyle="-", linewidth=0.5)
        
        dir = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/ECEF_PTE_Data/"
        os.makedirs(dir, exist_ok=True)  
        output_file = os.path.join(dir, f"lateral_error_path_pair_{idx+1}.txt")
        np.savetxt(output_file, reference_df["PathError"].to_numpy(), fmt="%.6f")
        print(f"Lateral error for Path Pair {idx+1} exported to {output_file}")
    
    plt.show()


if __name__ == "__main__":
    main()
    
    
    
    
    
    
    
    