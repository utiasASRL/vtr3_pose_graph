import os
from matplotlib import pyplot as plt
import numpy as np

import pandas as pd
from pylgmath import Transformation, Rotation
import vtr_regression_testing.path_comparison as vtr_path

def path_to_matrix(gps_data):
    """The vertices of the graph are assumed to be defined in the world frame."""
    
    #First 3 are the position of the start of the line, second three are the unit vector along the path segment
    points = np.zeros((0, 7))
    for idx in range(1, len(gps_data)):
        x0 = gps_data.iloc[idx - 1].array
        x1 = gps_data.iloc[idx].array

        # x0 = np.array([data_0['X'], data_0['Y'], data_0['Z']])
        # x1 = np.array([data_1['X'], data_1['Y'], data_1['Z']])
        l = np.linalg.norm(x1 - x0)
        n = (x1 - x0) / l
        row = np.zeros((1, 7))
        row[0, :3] = x0.T
        row[0, 3:6] = n.T
        row[0, 6] = l
        points = np.vstack((points, row))
    if points.shape[0] > 0:
        final_row = np.zeros((1, 7))
        final_row[0, :3] = x1.T
        final_row[0, 3:6] = -n.T
        final_row[0, 6] = l
        points = np.vstack((points, final_row))

    return points

def main(teach_path, repeat_path):
    teach_ins = pd.read_csv(teach_path)
    repeat_ins = pd.read_csv(repeat_path)

    teach_ins['Up(m)'] = 0
    repeat_ins['Up(m)'] = 0

    teach_matrix = path_to_matrix(teach_ins[["East(m)", "North(m)", "Up(m)"]])

    repeat_ins["PathError"] = repeat_ins[["East(m)", "North(m)", "Up(m)"]].apply(lambda row: vtr_path.signed_distance_to_path(row, teach_matrix), axis='columns', raw=True)
    fixed_error = [repeat_ins.iloc[0]['PathError']]
    for row in repeat_ins[1:].itertuples(index=False):
        if np.sign(row.PathError) != np.sign(fixed_error[-1]) and abs(row.PathError) > 0.1:
            fixed_error.append(-row.PathError)
        else:
            fixed_error.append(row.PathError)
    repeat_ins['FixedPathError'] = fixed_error


    repeat_ins.to_csv(repeat_path.replace(".csv", "_error.csv"), index=False)
    #plot error
    fig, ax = plt.subplots(6, 1, figsize=(10, 8))
    ax[0].plot(repeat_ins['Timestamp'], repeat_ins['PathError'])
    ax[0].set_ylabel('Path-Tracking Error (m)')
    ax[5].set_xlabel('Timestamp')

    #plot 3D of teach points 
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(teach_ins['East(m)'], teach_ins['North(m)'], teach_ins['Up(m)'], c='#D86900', label='teach')
    ax.scatter(repeat_ins['East(m)'], repeat_ins['North(m)'], repeat_ins['Up(m)'], c=repeat_ins['PathError'].abs(), label='repeat')
    ax.set_xlabel('X (East)')
    ax.set_ylabel('Y (North)')
    ax.set_zlabel('Z (Up)')
    ax.set_title('Teach and Repeat Points')
    ax.legend()
    ax.set_aspect('equal')
    plt.show()


if __name__ == "__main__":
    main(os.getenv("VTRDATA") + "/NorLabData/blue_nov_teach.csv", os.getenv("VTRDATA") + "/NorLabData/blue_nov_repeat_radar.csv")
    main(os.getenv("VTRDATA") + "/NorLabData/blue_jan_teach.csv", os.getenv("VTRDATA") + "/NorLabData/blue_jan_repeat_radar.csv")