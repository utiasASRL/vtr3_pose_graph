#!/usr/bin/env python3
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import NearestNeighbors
import vtr_regression_testing.path_comparison as vtr_path
from typing import Union, Optional

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def load_ecef_txt(path: str, skiprows: int = 16) -> pd.DataFrame:

    df = pd.read_csv(
        path,
        sep='\s+',
        header=None,
        skiprows=skiprows,
        names=['ID', 'ECEF-X', 'ECEF-Y', 'ECEF-Z']
    )
    df = df.dropna()
    df['ID'] = pd.to_numeric(df['ID'], errors='coerce')
    df = df.dropna(subset=['ID']).reset_index(drop=True)
    df[['ECEF-X','ECEF-Y','ECEF-Z']] = df[['ECEF-X','ECEF-Y','ECEF-Z']].astype(float)
    return df

def compute_errors(teach_df: pd.DataFrame, repeat_df: pd.DataFrame) -> pd.DataFrame:

    mat = path_to_matrix(teach_df[['ECEF-X','ECEF-Y','ECEF-Z']])#.to_numpy())
    #repeat_df = repeat_df.copy()
    # repeat_df['PathError'] = repeat_df[['ECEF-X','ECEF-Y','ECEF-Z']]\
    #     .apply(lambda r: vtr_path.signed_distance_to_path(r.to_numpy(), mat), axis=1)
    # return repeat_df
    errors = repeat_df[['ECEF-X', 'ECEF-Y', 'ECEF-Z']].apply(
        lambda row: vtr_path.signed_distance_to_path(row.to_numpy(), mat), axis=1)
    repeat_df["PathError"] = errors
    return repeat_df

def load_and_trim(path: str, omit_start: int, omit_end: int) -> pd.DataFrame:

    df = load_ecef_txt(path)
    if omit_end > 0:
        df = df.iloc[omit_start : -omit_end].reset_index(drop=True)
    else:
        df = df.iloc[omit_start : ].reset_index(drop=True)
    return df

def path_to_matrix(xyz: np.ndarray) -> np.ndarray:

    points = []
    for i in range(1, len(xyz)):
        p0, p1 = xyz[i-1], xyz[i]
        L = np.linalg.norm(p1 - p0)
        if L < 1e-6:
            continue
        n = (p1 - p0) / L
        points.append(np.hstack([p0, n, [L]]))
    if points:
        last = points[-1]
        points.append(np.hstack([last[:3], -last[3:6], [last[6]]]))
        return np.vstack(points)
    else:
        return np.empty((0,7))

def compute_errors(teach_df: pd.DataFrame, repeat_df: pd.DataFrame) -> pd.DataFrame:

    mat = path_to_matrix(teach_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy())
    repeat_df = repeat_df.copy()
    repeat_df['PathError'] = repeat_df[['ECEF-X','ECEF-Y','ECEF-Z']]\
        .apply(lambda r: vtr_path.signed_distance_to_path(r.to_numpy(), mat), axis=1)
    return repeat_df

def icp_align(source_df: pd.DataFrame,
              target_df: pd.DataFrame,
              max_iterations: int = 50,
              tolerance: float = 1e-6,
              return_transform: bool = False
) -> Union[pd.DataFrame, tuple[pd.DataFrame,np.ndarray,np.ndarray]]:

    src = source_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
    tgt = target_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
    prev_error = float('inf')

    # initialize net transform = identity
    R_net = np.eye(3)
    t_net = np.zeros(3)

    for _ in range(max_iterations):
        # find closest target points Q for each src
        nbrs = NearestNeighbors(n_neighbors=1).fit(tgt)
        dists, idxs = nbrs.kneighbors(src)
        Q = tgt[idxs.flatten()]

        # center
        c_src, c_tgt = src.mean(axis=0), Q.mean(axis=0)
        P0, Q0 = src - c_src, Q - c_tgt

        # SVD → R, t
        H = P0.T @ Q0
        U, _, Vt = np.linalg.svd(H)
        R = Vt.T @ U.T
        if np.linalg.det(R) < 0:
            Vt[-1,:] *= -1
            R = Vt.T @ U.T
        t = c_tgt - R @ c_src

        # accumulate net
        R_net = R @ R_net
        t_net = R @ t_net + t

        # apply to all src points
        src = (R @ src.T).T + t

        # check convergence
        mean_error = dists.mean()
        if abs(prev_error - mean_error) < tolerance:
            break
        prev_error = mean_error

    # build output DataFrame
    out = source_df.copy()
    out[['ECEF-X','ECEF-Y','ECEF-Z']] = src

    if return_transform:
        return out, R_net, t_net
    else:
        return out

def marker_icp_align(source_df: pd.DataFrame,
                     target_df: pd.DataFrame,
                     src_idxs: list[int],
                     tgt_idxs: list[int]) -> pd.DataFrame:

    P = source_df.loc[src_idxs, ['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
    Q = target_df.loc[tgt_idxs, ['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
    if P.shape != Q.shape or P.shape[0] < 3:
        raise ValueError("Need ≥3 correspondences of same shape")
    cP, cQ = P.mean(axis=0), Q.mean(axis=0)
    P0, Q0 = P - cP, Q - cQ
    H = P0.T @ Q0
    U, _, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1,:] *= -1
        R = Vt.T @ U.T
    t = cQ - R @ cP

    all_pts = source_df[['ECEF-X','ECEF-Y','ECEF-Z']].to_numpy()
    aligned = (R @ all_pts.T).T + t
    out = source_df.copy()
    out[['ECEF-X','ECEF-Y','ECEF-Z']] = aligned
    return out

def plot_overlaid_df_trajectories(df_list1: list[pd.DataFrame],
                                  df_list2: list[pd.DataFrame],
                                  suptitle: str = "Overlaid Trajectories") -> None:

    n = len(df_list1)
    rows = 1 if n == 2 else int(np.ceil(np.sqrt(n)))
    cols = n // rows + (n % rows > 0)
    fig, axs = plt.subplots(rows, cols, figsize=(6*cols, 5*rows))
    axs = np.atleast_1d(axs).flatten()

    for i, (d1, d2) in enumerate(zip(df_list1, df_list2)):
        ax = axs[i]
        x1 = -d1['ECEF-X'].to_numpy()
        y1 = -d1['ECEF-Y'].to_numpy()
        x2 = -d2['ECEF-X'].to_numpy()
        y2 = -d2['ECEF-Y'].to_numpy()
        ax.plot(x2, y2, '-', color="blue", label="Aligned Trajectory (Virtual Teach 'GPS')", linewidth=2)
        ax.plot(x1, y1, '--', color="red", label="Reference Trajectory (Repeat GPS)", linewidth=2)
        # Add green dot at the beginning and red dot at the end
        ax.scatter(x2[0], y2[0], color="green", s=50, label="Start Point (Aligned)", zorder=5)
        ax.scatter(x2[-1], y2[-1], color="red", s=50, label="End Point (Aligned)", zorder=5)
        ax.scatter(x1[0], y1[0], color="green", s=50, zorder=5)
        ax.scatter(x1[-1], y1[-1], color="red", s=50, zorder=5)
        ax.set_aspect('equal', 'box')
        ax.grid(True)
        ax.set_title(f"Pair {i+1}")
        if i == 0:
            ax.legend()

    for j in range(i+1, len(axs)):
        fig.delaxes(axs[j])
    plt.suptitle(suptitle)
    plt.tight_layout(rect=[0,0,1,0.95])
    plt.show()

def plot_path_df(df_list1: list[pd.DataFrame],
                 df_list2: list[pd.DataFrame],
                 file_names: list[str],
                 method: str,
                 suptitle: str = "Error Plot",
                 colorbar_title: str = "Error (m)") -> None:

    out_dir = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/ECEF_PTE_Data/"
    os.makedirs(out_dir, exist_ok=True)

    n = len(df_list1)
    rows = 1 if n == 2 else int(np.ceil(np.sqrt(n)))
    cols = n // rows + (n % rows > 0)
    fig, axs = plt.subplots(rows, cols, figsize=(6*cols, 5*rows))
    axs = np.atleast_1d(axs).flatten()

    all_abs = []
    results = []
    for d1, d2, fname in zip(df_list1, df_list2, file_names):
        err_df = compute_errors(d1, d2)
        # compute metrics
        errors = err_df['PathError'].to_numpy()
        rmse = np.sqrt(np.mean(errors**2))
        max_err = np.max(np.abs(errors))
        print(f"{os.path.basename(fname)} ({method}): RMSE = {rmse:.3f} m, Max = {max_err:.3f} m")
        # save raw PTE values
        base = os.path.splitext(os.path.basename(fname))[0]
        outfile = os.path.join(out_dir, f"{base}_pte_{method}.txt")
        np.savetxt(outfile, errors, fmt="%.6f")
        print(f"Saved PTE for {base} ({method}) → {outfile}")
        results.append((d1, err_df))
        all_abs.extend(np.abs(errors))

    vmin, vmax = 0, max(all_abs) if all_abs else 1

    for i, (_, err_df) in enumerate(results):
        ax = axs[i]
        x = -err_df['ECEF-X'].to_numpy()
        y = -err_df['ECEF-Y'].to_numpy()
        sc = ax.scatter(x, y,
                        c=np.abs(err_df['PathError'].to_numpy()),
                        cmap='viridis', vmin=vmin, vmax=vmax, s=10)
        ax.set_aspect('equal', 'box')
        ax.grid(True)
        ax.set_title(f"Error Pair {i+1}")
    for j in range(i+1, len(axs)):
        fig.delaxes(axs[j])

    cax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(sc, cax=cax, label=colorbar_title)
    plt.suptitle(suptitle)
    plt.tight_layout(rect=[0,0,0.9,0.95])
    plt.show()

def get_indices_from_xy(df: pd.DataFrame,
                        coords: list[tuple[float,float]],
                        x_col: str = 'ECEF-X',
                        y_col: str = 'ECEF-Y') -> list[int]:

    pts = df[[x_col,y_col]].to_numpy()
    idxs = []
    for x,y in coords:
        dists = np.linalg.norm(pts - np.array([x,y]), axis=1)
        idxs.append(int(np.argmin(dists)))
    return idxs

def marker_icp_align_auto(source_df, target_df, gt_xy):
    # 1) get the GT marker indices in the target (just once!)
    tgt_idxs = get_indices_from_xy(target_df, gt_xy)

    # 2) for this particular repeat, find the nearest points to the SAME (X,Y) coords:
    src_idxs = get_indices_from_xy(source_df, gt_xy)

    # 3) run your existing SVD‐based ICP on those index lists:
    return marker_icp_align(source_df, target_df, src_idxs, tgt_idxs)

def get_marker_xy_from_times(
    raw_file: str,
    gt_file: str,
    start_time: float,
    marker_times: list[float],
) -> list[tuple[float, float]]:

    # 1) Load raw log; first column is epoch, then ECEF-X/Y/Z
    raw_df = pd.read_csv(
        raw_file,
        sep=r'\s+',
        header=None,
        skiprows=16,
        names=['epoch','ECEF-X','ECEF-Y','ECEF-Z'],
    )
    raw_df['epoch'] = pd.to_numeric(raw_df['epoch'], errors='coerce')
    raw_df = raw_df.dropna(subset=['epoch']).reset_index(drop=True)

    # 2) Rebase timestamps so they start exactly at start_time
    orig0 = raw_df['epoch'].iloc[0]
    # preserve the original spacing:
    raw_df['epoch'] = float(start_time) + (raw_df['epoch'] - orig0)
    # (If you know it's 0.1s/row, you could force it:
    # raw_df['epoch'] = float(start_time) + np.arange(len(raw_df)) * 0.10 )

    # 3) Compute relative time since start (0.0, 0.1, 0.2, …)
    raw_df['t_rel'] = raw_df['epoch'] - float(start_time)

    # 4) Find each marker’s closest row
    marker_xy = []
    for i, mt in enumerate(marker_times, 1):
        mt = float(mt)
        offset = mt - float(start_time)
        idx = raw_df['t_rel'].sub(offset).abs().idxmin()
        matched_trel = raw_df.loc[idx, 't_rel']
        x, y = raw_df.loc[idx, ['ECEF-X','ECEF-Y']]
        marker_xy.append((x, y))
        print(f"Marker {i:2d}: target t_rel={offset:.3f}s → idx={idx}, actual t_rel={matched_trel:.3f}s → (x,y)=({x:.6f},{y:.6f})")
        marker_xy.append((x, y))

    # 5) Plot GT path + all markers
    gt_df = load_ecef_txt(gt_file, skiprows=16)
    # convert Series → numpy arrays before plotting
    x_gt = -gt_df['ECEF-X'].to_numpy()
    y_gt = -gt_df['ECEF-Y'].to_numpy()
    x_mark = [-x for x,_ in marker_xy]
    y_mark = [-y for _,y in marker_xy]

    plt.figure(figsize=(8,6))
    plt.plot(x_gt, y_gt, '-', label='GT Path')
    plt.scatter(x_mark, y_mark, c='red', s=50, label='Markers')
    plt.xlabel('ECEF-X (m)')
    plt.ylabel('ECEF-Y (m)')
    plt.title('GT Path with Detected Marker Locations')
    plt.legend()
    plt.grid(True)
    plt.show()

    return marker_xy

def find_marker_positions(df: pd.DataFrame,
                          marker_xy: list[tuple[float, float]],
                          x_col: str = 'ECEF-X',
                          y_col: str = 'ECEF-Y'
) -> tuple[list[int], list[tuple[float, float]], list[float]]:
    """
    For each (x,y) in `marker_xy`, find the nearest (x_col,y_col) in df.
    Returns three lists: indices, positions, and 2D distances.
    """
    pts = df[[x_col, y_col]].to_numpy()
    idxs = []
    positions = []
    dists = []
    for mx, my in marker_xy:
        d = np.linalg.norm(pts - np.array([mx, my]), axis=1)
        i = int(np.argmin(d))
        idxs.append(i)
        px, py = pts[i]
        positions.append((px, py))
        dists.append(float(d[i]))
    return idxs, positions, dists

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    # === USER PARAMETERS ===
    # Paths for Parking loop:
    gp_gt_p = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parking_recovered_mesh_path_ecef.txt"
    gp_repeats_p = [
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_34_37.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_13_43.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_34_07.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-23_56_26.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parking/parkingppkECEF_novatel_data_2025_02_23-22_54_00.txt" #not measured
    ]
    # Trim [start,end] for each:
    gp_gt_trim_p = (46, 51)
    gp_repeats_trim_p = [(942,802),(718, 809),(771,888),(750,749),(762,819), (718,810)]

    parking_remove_idxs = []


    # Paths for Mars loop:
    gp_gt_m = "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/dome_recovered_mesh_path_ecef.txt"
    gp_repeats_m = [
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_08_52.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_22_14.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_33_40.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_45_29.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-19_56_58.txt",
        "/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dome/domeppkECEF_novatel_data_2025_02_25-18_29_53.txt" # not measured
    ]

    gp_gt_trim_m = (57, 105)
    gp_repeats_trim_m = [(212,19),(133, 58),(140,88),(139, 48),(129,40), (129,40)]

    mars_remove_idxs = []

    # === Use helper to compute GT marker XY coords from raw files & times ===
    # for Parking:
    parking_raw_file = '/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/parkingteach/parkingteachppkECEF.txt'
    parking_start_time = '1740173617.275629238'
    parking_marker_times = [
        #'1740173618.528000000', #spray painted both here - cutoff by trimming
        '1740173644.145631574',  #spray painted both here
        '1740173734.635998493',  
        '1740173793.985451428',
        '1740173869.681489399',
        '1740173952.872956555',
        '1740174028.452038838',
        '1740174096.330397755',
        '1740174170.565191862',
        '1740174228.910205260',
        '1740173644.145631574'
        #'1740173618.528000000' # cutoff by trimming
    ]
    parking_gt_xy = get_marker_xy_from_times(
        parking_raw_file,
        gp_gt_p,
        parking_start_time,
        parking_marker_times
    )

    # for Mars:
    mars_raw_file = '/home/desiree/ASRL/vtr3/data/processed_txt_ECEF/dometeach/dometeachppkECEF.txt'
    mars_start_time = '1740537808.367129590'
    mars_marker_times = [
        '1740537856.732332585',
        '1740537915.208267997',
        '1740538027.798453285',
        '1740538066.247964487',
        '1740538092.071590682',
        '1740538121.832458139',
        '1740538154.489547849', 
        '1740538186.941014071'
    ]
    mars_gt_xy = get_marker_xy_from_times(
        mars_raw_file,
        gp_gt_m,
        mars_start_time,
        mars_marker_times
    )

    loops = [
      ("Parking", gp_gt_p, gp_repeats_p, gp_gt_trim_p, gp_repeats_trim_p,
       parking_gt_xy, parking_remove_idxs),
      ("Mars",    gp_gt_m, gp_repeats_m, gp_gt_trim_m, gp_repeats_trim_m,
       mars_gt_xy,    mars_remove_idxs)
    ]

    for name, gt_file, reps, gt_trim, rep_trims, gt_xy, remove_idxs in loops:
        print(f"\n\n=== {name} LOOP ===")

        # 1) load & trim (and drop any unwanted indices)
        gt = load_and_trim(gt_file, *gt_trim)
        if remove_idxs:
            gt = gt.drop(remove_idxs).reset_index(drop=True)

        # 2) load & trim each repeat
        repeats = [load_and_trim(f, *t) for f,t in zip(reps, rep_trims)]

        # (optional) Plot raw trimmed overlays:
        plot_overlaid_df_trajectories(repeats, [gt]*len(repeats),
                                      suptitle=f"{name}: Raw Trimmed Overlays")
    
        # 3) Global ICP
        icp_aligned = []
        icp_transforms = []   # will hold (R_net, t_net) for each repeat
        for r in repeats:
            r_icp, R_icp, t_icp = icp_align(r, gt, return_transform=True)
            icp_aligned.append(r_icp)
            icp_transforms.append((R_icp, t_icp))
        
        plot_overlaid_df_trajectories(icp_aligned, [gt]*len(icp_aligned),
                          suptitle=f"{name}: Global ICP-Aligned")
        plot_path_df(icp_aligned, [gt]*len(icp_aligned), reps,
                 method="global_icp",
                 suptitle=f"{name}: Lateral Error after Global ICP",
                 colorbar_title="|Error| (m)")
        
        # ── Snap timestamp-derived markers onto GT path
        print(f"\n→ Marker matches on GT ({name}):")
        gt_idxs, gt_marks, gt_dists = find_marker_positions(gt, gt_xy)
        for j, (i, (px, py), d) in enumerate(zip(gt_idxs, gt_marks, gt_dists), start=1):
            print(f"  Marker {j:2d}: idx={i:4d}, GT_pos=({px:.3f},{py:.3f}), dist={d:.3f} m")

        # ── Snap onto each ICP-aligned repeat
        for rep_i, r_icp in enumerate(icp_aligned, start=1):
            print(f"\n→ Marker matches on Repeat {rep_i} ({name}):")
            rep_idxs, rep_marks, rep_dists = find_marker_positions(r_icp, gt_xy)
            for j, (i, (px, py), d) in enumerate(zip(rep_idxs, rep_marks, rep_dists), start=1):
                print(f"  Marker {j:2d}: idx={i:4d}, Rep_pos=({px:.3f},{py:.3f}), dist={d:.3f} m")

        plt.figure(figsize=(8, 6))

        # 1) Plot GT trajectory
        x_gt = -gt['ECEF-X'].to_numpy()
        y_gt = -gt['ECEF-Y'].to_numpy()
        plt.plot(x_gt, y_gt, '-', color='black', linewidth=2, label='GT Path')

        # 2) Plot GT markers (rigidly transformed)
        gt_idxs, _, _ = find_marker_positions(gt, gt_xy)
        gt_marker_xyz = [
            (gt.loc[i, 'ECEF-X'], gt.loc[i, 'ECEF-Y'], gt.loc[i, 'ECEF-Z'])
            for i in gt_idxs
        ]
        transformed_gt_markers = [np.array(p) for p in gt_marker_xyz]  # No transformation applied to GT
        xs_gtm = [-p[0] for p in transformed_gt_markers]
        ys_gtm = [-p[1] for p in transformed_gt_markers]
        plt.scatter(xs_gtm, ys_gtm, c='red', s=80, marker='o', label='GT Markers', zorder=5)

        # 3) Plot each ICP‐aligned repeat trajectory
        for rep_i, r_icp in enumerate(icp_aligned, start=1):
            x_r = -r_icp['ECEF-X'].to_numpy()
            y_r = -r_icp['ECEF-Y'].to_numpy()
            plt.plot(x_r, y_r, '-', linewidth=2, label=f'Repeat {rep_i} ICP-Aligned')

        # 3.1) Plot signed distance to the path for each ICP-aligned repeat
        for rep_i, r_icp in enumerate(icp_aligned, start=1):
            errors_df = compute_errors(gt, r_icp)
            signed_distances = errors_df['PathError'].to_numpy()
            plt.figure(figsize=(10, 6))
            plt.plot(signed_distances, label=f'Repeat {rep_i} Signed Distance', linewidth=2)
            plt.axhline(0, color='black', linestyle='--', linewidth=1, label='Zero Error Line')
            plt.title(f"{name}: Signed Distance to Path (Repeat {rep_i})")
            plt.xlabel('Point Index')
            plt.ylabel('Signed Distance (m)')
            plt.grid(True)
            plt.legend()
            plt.show()

        # 4) Rigidly transform each repeat’s markers and plot
        for rep_i, (r_orig, (R_icp, t_icp)) in enumerate(zip(repeats, icp_transforms), start=1):
            pre_idxs, _, _ = find_marker_positions(r_orig, gt_xy)
            marker_pre_xyz = [
                (r_orig.loc[i, 'ECEF-X'], r_orig.loc[i, 'ECEF-Y'], r_orig.loc[i, 'ECEF-Z'])
                for i in pre_idxs
            ]
            transformed = [R_icp.dot(np.array(p)) + t_icp for p in marker_pre_xyz]
            xs = [-p[0] for p in transformed]
            ys = [-p[1] for p in transformed]
            plt.scatter(xs, ys, marker='x', s=80,
                        label=f'Repeat {rep_i} Rigid Markers', zorder=5)

        plt.title(f"{name}: GT & Repeat Paths with Rigid Marker Alignment")
        plt.xlabel('ECEF-X (m)')
        plt.ylabel('ECEF-Y (m)')
        plt.grid(True)
        plt.legend()
        plt.show()



        # 5) **Auto‐marker ICP on top of the global‐ICP result**
        auto_aligned = [
            marker_icp_align_auto(r_al, gt, gt_xy)
            for r_al in icp_aligned
        ]
    
        plot_overlaid_df_trajectories(auto_aligned, [gt]*len(auto_aligned),
                                      suptitle=f"{name}: Marker‐Refined ICP")
        plot_path_df(auto_aligned, [gt]*len(auto_aligned), reps,
                     method="marker_auto_icp",
                     suptitle=f"{name}: Lateral Error after Marker‐Refined ICP",
                     colorbar_title="|Error| (m)")

    print("\nAll done.")

if __name__ == "__main__":
    main()

